<?php

/* client/form.merchant.html.twig */
class __TwigTemplate_e1494a8106683342e9feb87333d163e01ecbedc30c0bfed5a943e76a3700bf6c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html.twig", "client/form.merchant.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Daftar Merchant";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "  <section id=\"support\" class=\"overview-block-ptb banner iq-bg iq-bg-fixed iq-box-shadow\" style=\" background: url(";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/header_blue.png);\">
    <div id=\"carousel-example-generic\" class=\"carousel slide\" data-ride=\"carousel\">
      <div class=\"container\">
        <div class=\"row\">
          <div class=\"col-sm-12\">
            <div class=\"heading-title\">
              <h2 class=\"title iq-tw-6\">Perndaftaran untuk Merchant</h2>
              <div class=\"divider\"></div>
              <!-- <p>YAP! adalah aplikasi yang menjadikan pembayaran menjadi lebih mudah. Banyak manfaat yang bisa anda dapatkan ketika mnejadikan YAP! bagian dari hidup anda.</p> -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- test -->

  <section class=\"overview-block-pb\">
    <iframe src=\"https://docs.google.com/forms/d/e/1FAIpQLScG_jsz_n_dv77Q21aj1HGKYohr4wlpibvUBl4wAd_jjhPMeA/viewform?embedded=true\" width=\"100%\" height=\"2100\" frameborder=\"0\" marginheight=\"0\" marginwidth=\"0\">Loading...</iframe>
  </section>

";
    }

    public function getTemplateName()
    {
        return "client/form.merchant.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 6,  35 => 5,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layouts/layout.html.twig' %}

{% block title %}Daftar Merchant{% endblock %}

{% block content %}
  <section id=\"support\" class=\"overview-block-ptb banner iq-bg iq-bg-fixed iq-box-shadow\" style=\" background: url({{ app.request.basepath }}/public/assets/img/header_blue.png);\">
    <div id=\"carousel-example-generic\" class=\"carousel slide\" data-ride=\"carousel\">
      <div class=\"container\">
        <div class=\"row\">
          <div class=\"col-sm-12\">
            <div class=\"heading-title\">
              <h2 class=\"title iq-tw-6\">Perndaftaran untuk Merchant</h2>
              <div class=\"divider\"></div>
              <!-- <p>YAP! adalah aplikasi yang menjadikan pembayaran menjadi lebih mudah. Banyak manfaat yang bisa anda dapatkan ketika mnejadikan YAP! bagian dari hidup anda.</p> -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- test -->

  <section class=\"overview-block-pb\">
    <iframe src=\"https://docs.google.com/forms/d/e/1FAIpQLScG_jsz_n_dv77Q21aj1HGKYohr4wlpibvUBl4wAd_jjhPMeA/viewform?embedded=true\" width=\"100%\" height=\"2100\" frameborder=\"0\" marginheight=\"0\" marginwidth=\"0\">Loading...</iframe>
  </section>

{% endblock %}
", "client/form.merchant.html.twig", "/Users/macos/Projects/yap_v3/src/Templates/client/form.merchant.html.twig");
    }
}
