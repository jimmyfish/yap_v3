<?php

/* client/event.html.twig */
class __TwigTemplate_dec0ea96388c405e607ee3a3916e5c3745e8b6f968ef083d0179e53272223923 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html.twig", "client/event.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Promo &amp; Blog";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "    <section id=\"support\" class=\"overview-block-ptb banner iq-bg iq-bg-fixed iq-box-shadow\"
             style=\" background: url(";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/header_blue.png);\">
        <div id=\"carousel-example-generic\" class=\"carousel slide\" data-ride=\"carousel\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-sm-12\">
                        <div class=\"heading-title\">
                            <h2 class=\"title iq-tw-6\">Promo &amp; Blog</h2>
                            <div class=\"divider\"></div>
                            <p>Jangan sampai terlewat, selalu cek berbagai promo dan informasi terbaru mengenai YAP!
                                disini.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id=\"blog\" class=\"overview-block-ptb white-bg iq-blog\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">Promo</h2>
                        <div class=\"divider\"></div>
                        <!--p>Jangan sampai terlewat, selalu cek berbagai promo dan informasi terbaru mengenai YAP! di
                            sini.</p-->
                    </div>
                </div>
            </div>

            ";
        // line 36
        if ((twig_length_filter($this->env, $this->getAttribute((isset($context["data"]) ? $context["data"] : $this->getContext($context, "data")), "promo", array(), "array")) > 0)) {
            // line 37
            echo "                ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["data"]) ? $context["data"] : $this->getContext($context, "data")), "promo", array(), "array"));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 38
                echo "                    <div class=\"col-sm-12 col-md-4\">
                        <div class=\"iq-blog-box\">
                            <div class=\"iq-blog-image clearfix\">
                                <img class=\"img-responsive center-block\"
                                     src=\"";
                // line 42
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
                echo "/public/photo/promo/";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "image", array()), "html", null, true);
                echo "\" alt=\"#\">
                            </div>
                            <div class=\"iq-blog-detail\">
                                <div class=\"blog-title\">
                                    <a href=\"";
                // line 46
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("promo_detail", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\">
                                        <h5 class=\"iq-tw-6 text-uppercase\">
                                            ";
                // line 48
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "title", array()), "html", null, true);
                echo "
                                        </h5>
                                    </a>
                                </div>
                                <div class=\"iq-blog-meta\">
                                    <ul class=\"list-inline\">
                                        <li>
                                            <a href=\"#\"><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i>
                                                &nbsp;";
                // line 56
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["item"], "tanggalBerlakuAwal", array()), "d M y"), "html", null, true);
                echo "
                                            </a>
                                        </li>
                                        <li>
                                            Kode Promo : <strong>";
                // line 60
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "kodePromo", array()), "html", null, true);
                echo "</strong>
                                        </li>
                                    </ul>
                                </div>
                                <div class=\"blog-content\">
                                    ";
                // line 65
                echo $this->getAttribute($context["item"], "content", array());
                echo "
                                </div>
                                <div class=\"blog-button\">
                                    <a href=\"#\" class=\"pull-left iq-tw-6 iq-user\">
                                        <i class=\"fa fa-user-circle\" aria-hidden=\"true\"></i>
                                        <span class=\"text-capitalize\">";
                // line 70
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "author", array()), "firstName", array()), "html", null, true);
                echo "</span>
                                    </a>
                                    <a href=\"";
                // line 72
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("promo_detail", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\" class=\"pull-right iq-tw-6\">Read
                                        More
                                        <i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 81
            echo "            ";
        }
        // line 82
        echo "
            <div class=\"col-sm-12 text-center\">
                <a class=\"button iq-mt-50\" href=\"";
        // line 84
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("promo_list");
        echo "\">Semua Promo</a>
            </div>
        </div>
    </section>
    <section id=\"blog\" class=\"overview-block-ptb white-bg iq-blog iq-pt-20\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">Blog</h2>
                        <div class=\"divider\"></div>
                        ";
        // line 96
        echo "                    </div>
                </div>
            </div>


            ";
        // line 101
        if ((twig_length_filter($this->env, $this->getAttribute((isset($context["data"]) ? $context["data"] : $this->getContext($context, "data")), "blog", array(), "array")) > 0)) {
            // line 102
            echo "                ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["data"]) ? $context["data"] : $this->getContext($context, "data")), "blog", array(), "array"));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 103
                echo "                    <div class=\"col-sm-12 col-md-4\">
                        <div class=\"iq-blog-box\">
                            <div class=\"iq-blog-image clearfix\">
                                <img class=\"img-responsive center-block\"
                                     src=\"";
                // line 107
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
                echo "/public/photo/blog/";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "image", array()), "html", null, true);
                echo "\" alt=\"#\">
                            </div>
                            <div class=\"iq-blog-detail\">
                                <div class=\"blog-title\">
                                    <a href=\"";
                // line 111
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_detail", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\">
                                        <h5 class=\"iq-tw-6 text-uppercase\">
                                            ";
                // line 113
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "title", array()), "html", null, true);
                echo "
                                        </h5>
                                    </a>
                                </div>
                                <div class=\"iq-blog-meta\">
                                    <ul class=\"list-inline\">
                                        <li>
                                            <a href=\"#\"><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i>
                                                &nbsp;";
                // line 121
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["item"], "date", array()), "d M y"), "html", null, true);
                echo "
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class=\"blog-content\">
                                    ";
                // line 127
                echo $this->getAttribute($context["item"], "content", array());
                echo "
                                </div>
                                <div class=\"blog-button\">
                                    <a href=\"#\" class=\"pull-left iq-tw-6 iq-user\">
                                        <i class=\"fa fa-user-circle\" aria-hidden=\"true\"></i>
                                        <span class=\"text-capitalize\">";
                // line 132
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "author", array()), "firstName", array()), "html", null, true);
                echo "</span>
                                    </a>
                                    <a href=\"";
                // line 134
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_detail", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\" class=\"pull-right iq-tw-6\">Read
                                        More
                                        <i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 143
            echo "            ";
        }
        // line 144
        echo "            <div class=\"row\">
                <div class=\"col-sm-12 text-center\">
                    <a class=\"button iq-mt-50\" href=\"";
        // line 146
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_list");
        echo "\">Semua Blog</a>
                </div>
            </div>
        </div>
    </section>
";
    }

    public function getTemplateName()
    {
        return "client/event.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  264 => 146,  260 => 144,  257 => 143,  242 => 134,  237 => 132,  229 => 127,  220 => 121,  209 => 113,  204 => 111,  195 => 107,  189 => 103,  184 => 102,  182 => 101,  175 => 96,  161 => 84,  157 => 82,  154 => 81,  139 => 72,  134 => 70,  126 => 65,  118 => 60,  111 => 56,  100 => 48,  95 => 46,  86 => 42,  80 => 38,  75 => 37,  73 => 36,  41 => 7,  38 => 6,  35 => 5,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layouts/layout.html.twig' %}

{% block title %}Promo &amp; Blog{% endblock %}

{% block content %}
    <section id=\"support\" class=\"overview-block-ptb banner iq-bg iq-bg-fixed iq-box-shadow\"
             style=\" background: url({{ app.request.basepath }}/public/assets/img/header_blue.png);\">
        <div id=\"carousel-example-generic\" class=\"carousel slide\" data-ride=\"carousel\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-sm-12\">
                        <div class=\"heading-title\">
                            <h2 class=\"title iq-tw-6\">Promo &amp; Blog</h2>
                            <div class=\"divider\"></div>
                            <p>Jangan sampai terlewat, selalu cek berbagai promo dan informasi terbaru mengenai YAP!
                                disini.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id=\"blog\" class=\"overview-block-ptb white-bg iq-blog\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">Promo</h2>
                        <div class=\"divider\"></div>
                        <!--p>Jangan sampai terlewat, selalu cek berbagai promo dan informasi terbaru mengenai YAP! di
                            sini.</p-->
                    </div>
                </div>
            </div>

            {% if data['promo']|length > 0 %}
                {% for item in data['promo'] %}
                    <div class=\"col-sm-12 col-md-4\">
                        <div class=\"iq-blog-box\">
                            <div class=\"iq-blog-image clearfix\">
                                <img class=\"img-responsive center-block\"
                                     src=\"{{ app.request.basepath }}/public/photo/promo/{{ item.image }}\" alt=\"#\">
                            </div>
                            <div class=\"iq-blog-detail\">
                                <div class=\"blog-title\">
                                    <a href=\"{{ path('promo_detail', {id: item.id}) }}\">
                                        <h5 class=\"iq-tw-6 text-uppercase\">
                                            {{ item.title }}
                                        </h5>
                                    </a>
                                </div>
                                <div class=\"iq-blog-meta\">
                                    <ul class=\"list-inline\">
                                        <li>
                                            <a href=\"#\"><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i>
                                                &nbsp;{{ item.tanggalBerlakuAwal|date('d M y') }}
                                            </a>
                                        </li>
                                        <li>
                                            Kode Promo : <strong>{{ item.kodePromo }}</strong>
                                        </li>
                                    </ul>
                                </div>
                                <div class=\"blog-content\">
                                    {{ item.content|raw }}
                                </div>
                                <div class=\"blog-button\">
                                    <a href=\"#\" class=\"pull-left iq-tw-6 iq-user\">
                                        <i class=\"fa fa-user-circle\" aria-hidden=\"true\"></i>
                                        <span class=\"text-capitalize\">{{ item.author.firstName }}</span>
                                    </a>
                                    <a href=\"{{ path('promo_detail', {id: item.id}) }}\" class=\"pull-right iq-tw-6\">Read
                                        More
                                        <i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                {% endfor %}
            {% endif %}

            <div class=\"col-sm-12 text-center\">
                <a class=\"button iq-mt-50\" href=\"{{ path('promo_list') }}\">Semua Promo</a>
            </div>
        </div>
    </section>
    <section id=\"blog\" class=\"overview-block-ptb white-bg iq-blog iq-pt-20\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">Blog</h2>
                        <div class=\"divider\"></div>
                        {# <p>Jangan sampai terlewat, selalu cek berbagai promo dan informasi terbaru mengenai YAP! di sini.</p> #}
                    </div>
                </div>
            </div>


            {% if data['blog']|length > 0 %}
                {% for item in data['blog'] %}
                    <div class=\"col-sm-12 col-md-4\">
                        <div class=\"iq-blog-box\">
                            <div class=\"iq-blog-image clearfix\">
                                <img class=\"img-responsive center-block\"
                                     src=\"{{ app.request.basepath }}/public/photo/blog/{{ item.image }}\" alt=\"#\">
                            </div>
                            <div class=\"iq-blog-detail\">
                                <div class=\"blog-title\">
                                    <a href=\"{{ path('blog_detail', {id: item.id}) }}\">
                                        <h5 class=\"iq-tw-6 text-uppercase\">
                                            {{ item.title }}
                                        </h5>
                                    </a>
                                </div>
                                <div class=\"iq-blog-meta\">
                                    <ul class=\"list-inline\">
                                        <li>
                                            <a href=\"#\"><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i>
                                                &nbsp;{{ item.date|date('d M y') }}
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class=\"blog-content\">
                                    {{ item.content|raw }}
                                </div>
                                <div class=\"blog-button\">
                                    <a href=\"#\" class=\"pull-left iq-tw-6 iq-user\">
                                        <i class=\"fa fa-user-circle\" aria-hidden=\"true\"></i>
                                        <span class=\"text-capitalize\">{{ item.author.firstName }}</span>
                                    </a>
                                    <a href=\"{{ path('blog_detail', {id: item.id}) }}\" class=\"pull-right iq-tw-6\">Read
                                        More
                                        <i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                {% endfor %}
            {% endif %}
            <div class=\"row\">
                <div class=\"col-sm-12 text-center\">
                    <a class=\"button iq-mt-50\" href=\"{{ path('blog_list') }}\">Semua Blog</a>
                </div>
            </div>
        </div>
    </section>
{% endblock %}", "client/event.html.twig", "/Users/macos/Projects/yap_v3/src/Templates/client/event.html.twig");
    }
}
