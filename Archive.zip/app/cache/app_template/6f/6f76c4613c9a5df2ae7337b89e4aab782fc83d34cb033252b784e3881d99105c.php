<?php

/* client/tentang.html.twig */
class __TwigTemplate_72255c19135c86b755ef1efea659e8d41516da6dfd2629e2119a9de0fae6ba0b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html.twig", "client/tentang.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Tentang Kami";
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <!-- Frequently Asked Questions -->
    <section id=\"support\" class=\"overview-block-ptb banner iq-bg iq-bg-fixed iq-box-shadow\" style=\" background: url(";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/header_blue.png);\">
        <div id=\"carousel-example-generic\" class=\"carousel slide\" data-ride=\"carousel\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-sm-12\">
                        <div class=\"heading-title\">
                            <h2 class=\"title iq-tw-6\">Tentang Kami</h2>
                            <div class=\"divider\"></div>
                            <!-- <p>YAP! adalah aplikasi yang menjadikan pembayaran menjadi lebih mudah. Banyak manfaat yang bisa anda dapatkan ketika mnejadikan YAP! bagian dari hidup anda.</p> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class=\"iq-about grey-bg iq-mtb-40\">
        <div class=\"container\">
            <div class=\"row row-eq-height\">
                <div class=\"col-sm-12 col-lg-5 col-md-5 iq-about-bg\">
                    <div class=\"iq-bg about-img popup-gallery play-video\">
                        <img class=\"img-responsive center-block\" src=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/scr3.png\" alt=\"#\">
                        <a href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/video/main.mp4\" class=\"iq-video popup-youtube\">
                            <i class=\"ion-ios-play-outline\"></i>
                        </a>
                        <div class=\"iq-waves\">
                            <div class=\"waves wave-1\"></div>
                            <div class=\"waves wave-2\"></div>
                            <div class=\"waves wave-3\"></div>
                        </div>
                    </div>
                </div>
                <div class=\"col-sm-12 col-lg-7 col-md-7 iq-pall-50\">
                    <h2 class=\"heading-left iq-tw-6 \">Tentang Aplikasi YAP!</h2>
                    <p>Aplikasi YAP! merupakan suatu solusi metode pembayaran yang memungkinkan Nasabah menjadi inisiator atas transaksi di merchant. Metode pembayaran ini memerlukan media berupa aplikasi mobile yang dimiliki oleh nasabah dan merchant. Metode pembayaran
                    yang digunakan saat transaksi adalah dengan menggunakan QR Code scanner. Aplikasi YAP! telah disediakan dalam Android dan iOS dan setiap device harus terkoneksi dengan jaringan internet</p>
                    <a class=\"button iq-mt-15\" href=\"# \">Download Manual Book</a>
                </div>
            </div>
        </div>
    </section>
    <section class=\"overview-block-ptb white-bg\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">Mengapa yap!</h2>
                        <div class=\"divider\"></div>
                        <p>yap! adalah aplikasi yang menjadikan pembayaran menjadi lebih mudah. Banyak manfaat yang bisa anda dapatkan ketika menjadikan yap! bagian dari hidup anda.</p>
                    </div>
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-12 col-md-6\">
                    <img class=\"img-responsive center-block\" src=\"";
        // line 58
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/samsung_and_hand.png\" alt=\"\">
                </div>
                <div class=\"col-sm-12 col-md-6\">
                    <div class=\"iq-accordion iq-mt-50\">
                        <div class=\"ad-block ad-active\">
                            <a href=\"\" class=\"ad-title iq-tw-6 iq-font-grey\">
                                <span class=\"ad-icon\">
                                    <i class=\"ion-ios-infinite-outline\" aria-hidden=\"true\"></i>
                                </span>
                                Kemudahan bertransaksi
                            </a>
                            <div class=\"ad-details\">
                                <div class=\"row\">
                                    <div class=\"col-sm-12\">
                                        Kamu dapat berbelanja pada offline store yang merupakan merchant yap! dan marketplace yang merupakan mitra yap!
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class=\"ad-block\">
                            <a href=\"#\" class=\"ad-title iq-tw-6 iq-font-grey\">
                                <span class=\"ad-icon\">
                                    <i class=\"ion-ios-time-outline\" aria-hidden=\"true\"></i>
                                </span>
                                Keamanan lebih utama
                            </a>
                            <div class=\"ad-details\">
                                Kami mengutamakan Keamanan dalam transaksi yang berlangsung dengan Konsumen Anda. Baik dari sisi Anda sebagai merchant ataupun Konsumen.
                            </div>
                        </div>
                        <div class=\"ad-block\">
                            <a href=\"";
        // line 89
        echo "#";
        echo "\" class=\"ad-title iq-tw-6 iq-font-grey\">
                                <span class=\"ad-icon\">
                                    <i class=\"ion-ios-compose-outline\" aria-hidden=\"true\"></i>
                                </span>
                                Solusi Pembayaran Online
                            </a>
                            <div class=\"ad-details\">
                                <div class=\"row\">
                                    <div class=\"col-sm-12\">
                                        YAP! juga memiliki tools terintegrasi ke e-commerce yang Anda butuhkan sebagai alat pembayaran secara online, dengan transaksi debit, kartu kredit, bahkan penarikan uang.
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class=\"ad-block\">
                            <a href=\"#\" class=\"ad-title iq-tw-6 iq-font-grey\">
                                <span class=\"ad-icon\">
                                    <i class=\"ion-ios-loop\" aria-hidden=\"true\"></i>
                                </span>
                                Top up deposite mudah
                            </a>
                            <div class=\"ad-details\">
                                Anda dapat Deposit menggunakan ATM manapun dari 137 BANK di Indonesia.
                                Deposit melalui Mobile Banking, Internet Banking, maupun Setor  Tunai.
                            </div>
                        </div>
                        <div class=\"ad-block\">
                            <a href=\"#\" class=\"ad-title iq-tw-6 iq-font-grey\">
                                <span class=\"ad-icon\">
                                    <i class=\"ion-ios-cart-outline\" aria-hidden=\"true\"></i>
                                </span>
                                Kemudahan transaksi
                            </a>
                            <div class=\"ad-details\">
                                <ul class=\"circle iq-plr-20\">
                                    <li>
                                        Berbelanja pada offline store yang merupakan merchant YAP!mu
                                    </li>
                                    <li>
                                        Berbelanja pada marketplace yang merupakan mitra YAP!
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class=\"ad-block\">
                            <a href=\"#\" class=\"ad-title iq-tw-6 iq-font-grey\">
                                <span class=\"ad-icon\">
                                    <i class=\"ion-ios-checkmark-outline\" aria-hidden=\"true\"></i>
                                </span>
                                Cara Kerja
                            </a>
                            <div class=\"ad-details\">
                                <ul class=\"number iq-plr-20\">
                                    <li>
                                        Daftar di Aplikasi YAP!
                                    </li>
                                    <li>
                                        Lakukan verifikasi
                                    </li>
                                    <li>
                                        Setelah akun Anda diverifikasi Anda bisa menggunakan semua Fitur YAP!.
                                    </li>
                                    <li>
                                        Dengan YAP Anda bisa menerima uang, penarikan uang ke Bank, maupun berbelanja di merchant YAP!mu
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
";
    }

    public function getTemplateName()
    {
        return "client/tentang.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 89,  103 => 58,  68 => 26,  64 => 25,  41 => 5,  38 => 4,  35 => 3,  29 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layouts/layout.html.twig' %}
{% block title %}Tentang Kami{% endblock %}
{% block content %}
    <!-- Frequently Asked Questions -->
    <section id=\"support\" class=\"overview-block-ptb banner iq-bg iq-bg-fixed iq-box-shadow\" style=\" background: url({{ app.request.basepath }}/public/assets/img/header_blue.png);\">
        <div id=\"carousel-example-generic\" class=\"carousel slide\" data-ride=\"carousel\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-sm-12\">
                        <div class=\"heading-title\">
                            <h2 class=\"title iq-tw-6\">Tentang Kami</h2>
                            <div class=\"divider\"></div>
                            <!-- <p>YAP! adalah aplikasi yang menjadikan pembayaran menjadi lebih mudah. Banyak manfaat yang bisa anda dapatkan ketika mnejadikan YAP! bagian dari hidup anda.</p> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class=\"iq-about grey-bg iq-mtb-40\">
        <div class=\"container\">
            <div class=\"row row-eq-height\">
                <div class=\"col-sm-12 col-lg-5 col-md-5 iq-about-bg\">
                    <div class=\"iq-bg about-img popup-gallery play-video\">
                        <img class=\"img-responsive center-block\" src=\"{{ app.request.basepath }}/public/assets/img/scr3.png\" alt=\"#\">
                        <a href=\"{{ app.request.basepath }}/public/assets/video/main.mp4\" class=\"iq-video popup-youtube\">
                            <i class=\"ion-ios-play-outline\"></i>
                        </a>
                        <div class=\"iq-waves\">
                            <div class=\"waves wave-1\"></div>
                            <div class=\"waves wave-2\"></div>
                            <div class=\"waves wave-3\"></div>
                        </div>
                    </div>
                </div>
                <div class=\"col-sm-12 col-lg-7 col-md-7 iq-pall-50\">
                    <h2 class=\"heading-left iq-tw-6 \">Tentang Aplikasi YAP!</h2>
                    <p>Aplikasi YAP! merupakan suatu solusi metode pembayaran yang memungkinkan Nasabah menjadi inisiator atas transaksi di merchant. Metode pembayaran ini memerlukan media berupa aplikasi mobile yang dimiliki oleh nasabah dan merchant. Metode pembayaran
                    yang digunakan saat transaksi adalah dengan menggunakan QR Code scanner. Aplikasi YAP! telah disediakan dalam Android dan iOS dan setiap device harus terkoneksi dengan jaringan internet</p>
                    <a class=\"button iq-mt-15\" href=\"# \">Download Manual Book</a>
                </div>
            </div>
        </div>
    </section>
    <section class=\"overview-block-ptb white-bg\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">Mengapa yap!</h2>
                        <div class=\"divider\"></div>
                        <p>yap! adalah aplikasi yang menjadikan pembayaran menjadi lebih mudah. Banyak manfaat yang bisa anda dapatkan ketika menjadikan yap! bagian dari hidup anda.</p>
                    </div>
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-12 col-md-6\">
                    <img class=\"img-responsive center-block\" src=\"{{ app.request.basepath }}/public/assets/img/samsung_and_hand.png\" alt=\"\">
                </div>
                <div class=\"col-sm-12 col-md-6\">
                    <div class=\"iq-accordion iq-mt-50\">
                        <div class=\"ad-block ad-active\">
                            <a href=\"\" class=\"ad-title iq-tw-6 iq-font-grey\">
                                <span class=\"ad-icon\">
                                    <i class=\"ion-ios-infinite-outline\" aria-hidden=\"true\"></i>
                                </span>
                                Kemudahan bertransaksi
                            </a>
                            <div class=\"ad-details\">
                                <div class=\"row\">
                                    <div class=\"col-sm-12\">
                                        Kamu dapat berbelanja pada offline store yang merupakan merchant yap! dan marketplace yang merupakan mitra yap!
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class=\"ad-block\">
                            <a href=\"#\" class=\"ad-title iq-tw-6 iq-font-grey\">
                                <span class=\"ad-icon\">
                                    <i class=\"ion-ios-time-outline\" aria-hidden=\"true\"></i>
                                </span>
                                Keamanan lebih utama
                            </a>
                            <div class=\"ad-details\">
                                Kami mengutamakan Keamanan dalam transaksi yang berlangsung dengan Konsumen Anda. Baik dari sisi Anda sebagai merchant ataupun Konsumen.
                            </div>
                        </div>
                        <div class=\"ad-block\">
                            <a href=\"{{ '#' }}\" class=\"ad-title iq-tw-6 iq-font-grey\">
                                <span class=\"ad-icon\">
                                    <i class=\"ion-ios-compose-outline\" aria-hidden=\"true\"></i>
                                </span>
                                Solusi Pembayaran Online
                            </a>
                            <div class=\"ad-details\">
                                <div class=\"row\">
                                    <div class=\"col-sm-12\">
                                        YAP! juga memiliki tools terintegrasi ke e-commerce yang Anda butuhkan sebagai alat pembayaran secara online, dengan transaksi debit, kartu kredit, bahkan penarikan uang.
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class=\"ad-block\">
                            <a href=\"#\" class=\"ad-title iq-tw-6 iq-font-grey\">
                                <span class=\"ad-icon\">
                                    <i class=\"ion-ios-loop\" aria-hidden=\"true\"></i>
                                </span>
                                Top up deposite mudah
                            </a>
                            <div class=\"ad-details\">
                                Anda dapat Deposit menggunakan ATM manapun dari 137 BANK di Indonesia.
                                Deposit melalui Mobile Banking, Internet Banking, maupun Setor  Tunai.
                            </div>
                        </div>
                        <div class=\"ad-block\">
                            <a href=\"#\" class=\"ad-title iq-tw-6 iq-font-grey\">
                                <span class=\"ad-icon\">
                                    <i class=\"ion-ios-cart-outline\" aria-hidden=\"true\"></i>
                                </span>
                                Kemudahan transaksi
                            </a>
                            <div class=\"ad-details\">
                                <ul class=\"circle iq-plr-20\">
                                    <li>
                                        Berbelanja pada offline store yang merupakan merchant YAP!mu
                                    </li>
                                    <li>
                                        Berbelanja pada marketplace yang merupakan mitra YAP!
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class=\"ad-block\">
                            <a href=\"#\" class=\"ad-title iq-tw-6 iq-font-grey\">
                                <span class=\"ad-icon\">
                                    <i class=\"ion-ios-checkmark-outline\" aria-hidden=\"true\"></i>
                                </span>
                                Cara Kerja
                            </a>
                            <div class=\"ad-details\">
                                <ul class=\"number iq-plr-20\">
                                    <li>
                                        Daftar di Aplikasi YAP!
                                    </li>
                                    <li>
                                        Lakukan verifikasi
                                    </li>
                                    <li>
                                        Setelah akun Anda diverifikasi Anda bisa menggunakan semua Fitur YAP!.
                                    </li>
                                    <li>
                                        Dengan YAP Anda bisa menerima uang, penarikan uang ke Bank, maupun berbelanja di merchant YAP!mu
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
{% endblock %}", "client/tentang.html.twig", "/Users/macos/Projects/yap_v3/src/Templates/client/tentang.html.twig");
    }
}
