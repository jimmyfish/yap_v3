<?php

/* client/support.html.twig */
class __TwigTemplate_2a3ea8b1276f13e4eeebbf9db60eb8dec66a5f4d40687eb117aca1b7adc15bd7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html.twig", "client/support.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
            'customJS' => array($this, 'block_customJS'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Dukungan";
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "  <!-- Frequently Asked Questions -->
  <section id=\"support\" class=\"overview-block-ptb banner iq-bg iq-bg-fixed iq-box-shadow\" style=\" background: url(";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/header_blue.png);\">
    <div id=\"carousel-example-generic\" class=\"carousel slide\" data-ride=\"carousel\">
      <div class=\"container\">
        <div class=\"row\">
          <div class=\"col-sm-12\">
            <div class=\"heading-title\">
              <h2 class=\"title iq-tw-6\">Mekanisme Aplikasi yap! Bagi Customer</h2>
              <div class=\"divider\"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section id=\"mekanism\" class=\"overview-block-ptb\">
    <div class=\"container\">
      ";
        // line 29
        echo "      <div class=\"row\">
        <div class=\"col-sm-12 col-md-6 col-lg-6\">
          <img src=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/infografik.png\" alt=\"\" class=\"img-responsive infografik\">
        </div>
        <div class=\"col-sm-12 col-md-6 col-lg-6 mt-sm\">
          <div class=\"row step iq-mb-15\">
            <div class=\"col-xs-2 h72\">
              <div class=\"iq-icon magical\">
                1
              </div>
            </div>
            <div class=\"col-xs-10 tc\">
              <span class=\"magical\">Nasabah/Customer datang ke merchant</span>
            </div>
          </div>
          <div class=\"row step iq-mb-15\">
            <div class=\"col-xs-2 h72\">
              <div class=\"iq-icon magical\">
                2
              </div>
            </div>
            <div class=\"col-xs-10 tc\">
              <span class=\"magical\">Merchant menampilkan QR Code sebagai media untuk transaksi</span>
            </div>
          </div>
          <div class=\"row step iq-mb-15\">
            <div class=\"col-xs-2 h72\">
              <div class=\"iq-icon magical\">
                3
              </div>
            </div>
            <div class=\"col-xs-10 tc\">
              <span class=\"magical\">Nasabah/Customer login ke yap!</span>
            </div>
          </div>
          <div class=\"row step iq-mb-15\">
            <div class=\"col-xs-2 h72\">
              <div class=\"iq-icon magical\">
                4
              </div>
            </div>
            <div class=\"col-xs-10 tc\">
              <span class=\"magical\">Nasabah/Customer melakukan scanning QR Code, input nominal transaksi dan Pin Kartu Kredit yang divalidasi oleh host Bank.</span>
            </div>
          </div>
          <div class=\"row step iq-mb-15\">
            <div class=\"col-xs-2 h72\">
              <div class=\"iq-icon magical\">
                5
              </div>
            </div>
            <div class=\"col-xs-10 tc\">
              <span class=\"magical\">Transaksi berhasil. Notifikasi transaksi akan dikirimkan ke nasabah dan merchant</span>
            </div>
          </div>
          <div class=\"row step iq-mb-15\">
            <div class=\"col-xs-2 h72\">
              <div class=\"iq-icon magical\">
                6
              </div>
            </div>
            <div class=\"col-xs-10 tc\">
              <span class=\"magical\">Transaksi Berhasil</span>
            </div>
          </div>
          <div class=\"jumbotron\">
            <h5>Penggunaan 6 Digit PIN merupakan pemenuhan SEBI No. 16/25/DKSP/ Tanggal 31 Desember 2014</h5>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section>
    <div class=\"container\">
      <div class=\"row\">
        <div class=\"col-sm-12\">
          <div class=\"heading-title\">
            <h2 class=\"title iq-tw-6\">Cara Menggunakan yap! bagi Customer</h2>
            <div class=\"divider\"></div>
            <!-- <p>YAP! adalah aplikasi yang menjadikan pembayaran menjadi lebih mudah. Banyak manfaat yang bisa anda dapatkan ketika mnejadikan YAP! bagian dari hidup anda.</p> -->
          </div>
        </div>
      </div>
    </div>
  </section>
  <section id=\"iq-home\" class=\"banner iq-bg iq-bg-fixed iq-box-shadow large-only\" style=\" background: url(";
        // line 114
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/header_blue.png);\">
    <div id=\"main-carousel\" class=\"carousel slide\" data-ride=\"carousel\">
      <!-- Indicators -->
      <ol class=\"carousel-indicators\">
        <li data-target=\"#main-carousel\" data-slide-to=\"0\" class=\"active\"></li>
        <li data-target=\"#main-carousel\" data-slide-to=\"1\"></li>
        <li data-target=\"#main-carousel\" data-slide-to=\"2\"></li>
        <li data-target=\"#main-carousel\" data-slide-to=\"3\"></li>
        <li data-target=\"#main-carousel\" data-slide-to=\"4\"></li>
        <li data-target=\"#main-carousel\" data-slide-to=\"5\"></li>
        <li data-target=\"#main-carousel\" data-slide-to=\"6\"></li>
        <li data-target=\"#main-carousel\" data-slide-to=\"7\"></li>
        <li data-target=\"#main-carousel\" data-slide-to=\"8\"></li>

      </ol>

      <!-- Wrapper for slides -->
      <div class=\"container iq-mb-30\">
        <div class=\"carousel-inner\" role=\"listbox\">
          <div class=\"item active\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 138
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/1.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 1</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Install Aplikasi yap! dari Play Store gadget Kamu.</h5>
                  <p>&nbsp;</p>
                  <div class=\"iq-fancy-box-05\">

                    <a class=\"iq-mr-15\" href=\"https://play.google.com/store/apps/details?id=id.co.bni.yapcustomer\"><img src=\"";
        // line 147
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/Playstore_Badge.png\" alt=\"Playstore\"></a>

                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- 2 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 160
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/2.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 2</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Setelah itu buka Aplikasi dan kamu akan menemukan keterangan User agreement</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 3 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 176
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/3.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 3</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Muncul keterangan keamanan, pilih NEXT</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 4 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 192
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/4.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 4</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Masukkan data Identitas kamu sesuai dengan form yang tersedia. jangan lupa membuat password untuk akses aplikasi yap!</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 6 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 208
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/5.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 5</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Ketika data sudah lengkap, kamu akan menerima informasi sukses. lanjutkan dengan melakukan login.</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 7 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 224
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/6.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 6</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Kamu akan masuk ke halaman login, masukkan user dan password yang telah dibuat</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 8 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 240
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/7.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 7</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Selanjutnya akan masuk ke proses pemilihan kartu yang akan digunakan untuk transaksi / aktivasi yap!. Bisa pilih Kartu Debit, Kartu Kredit atau UNIKQU.</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 9 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 256
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/8.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 8</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Kemudian masukkan Nomer ID Kartu atau Akun UNIKQU</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 10 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 272
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/9.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 9</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Masukkan UNIKQU PIN yang sudah tersedia di akun UNIKQU kamu.</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 11 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 288
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/10.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 10</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Kode OTP akan dikirim melalui SMS ke Nomor yang sudah terdaftar. masukkan ke Kolom Kode OTP.</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 12 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 304
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/11.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 11</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Akun yap! kamu sudah bisa digunakan.</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class=\"small-only\">
    <div class=\"container\">
      <div class=\"row\">
        <div id=\"customer-small-carousel\" class=\"tutorial\">
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 323
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/1.png\" alt=\"\">
            <h4>Step 1</h4>
            <p>Install Aplikasi yap! dari Play Store gadget Kamu.</p>
            <a href=\"https://play.google.com/store/apps/details?id=id.co.bni.yapcustomer\"><img src=\"";
        // line 326
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/Playstore_Badge.png\" alt=\"Playstore\"></a>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 329
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/2.png\" alt=\"\">
            <h4>Step 2</h4>
            <p>Setelah itu buka Aplikasi dan kamu akan menemukan keterangan User agreement</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 334
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/3.png\" alt=\"\">
            <h4>Step 3</h4>
            <p>Muncul keterangan keamanan, pilih NEXT</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 339
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/4.png\" alt=\"\">
            <h4>Step 4</h4>
            <p>Masukkan data Identitas kamu sesuai dengan form yang tersedia. jangan lupa membuat password untuk akses aplikasi yap!</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 344
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/5.png\" alt=\"\">
            <h4>Step 5</h4>
            <p>Ketika data sudah lengkap, kamu akan menerima informasi sukses. lanjutkan dengan melakukan login.</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 349
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/6.png\" alt=\"\">
            <h4>Step 6</h4>
            <p>Kamu akan masuk ke halaman login, masukkan user dan password yang telah dibuat</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 354
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/7.png\" alt=\"\">
            <h4>Step 7</h4>
            <p>Selanjutnya akan masuk ke proses pemilihan kartu yang akan digunakan untuk transaksi / aktivasi yap!. Bisa pilih Kartu Debit, Kartu Kredit atau UNIKQU.</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 359
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/8.png\" alt=\"\">
            <h4>Step 8</h4>
            <p>Kemudian masukkan Nomer ID Kartu atau Akun UNIKQU</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 364
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/9.png\" alt=\"\">
            <h4>Step 9</h4>
            <p>Masukkan UNIKQU PIN yang sudah tersedia di akun UNIKQU kamu.</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 369
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/10.png\" alt=\"\">
            <h4>Step 10</h4>
            <p>Kode OTP akan dikirim melalui SMS ke Nomor yang sudah terdaftar. masukkan ke Kolom Kode OTP.</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 374
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/step/transact/11.png\" alt=\"\">
            <h4>Step 11</h4>
            <p>Akun yap! kamu sudah bisa digunakan.</p>
          </div>
        </div>
      </div>
    </div>
  </section>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <section>
    <div class=\"container\">
      <div class=\"row\">
        <div class=\"col-sm-12\">
          <div class=\"heading-title\">
            <h2 class=\"title iq-tw-6\">Cara Menggunakan yap! bagi Merchant</h2>
            <div class=\"divider\"></div>
            <!-- <p>YAP! adalah aplikasi yang menjadikan pembayaran menjadi lebih mudah. Banyak manfaat yang bisa anda dapatkan ketika mnejadikan YAP! bagian dari hidup anda.</p> -->
          </div>
        </div>
      </div>
    </div>
  </section>
  <section id=\"iq-home\" class=\"banner iq-bg iq-bg-fixed iq-box-shadow large-only\" style=\" background: url(";
        // line 398
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/header_blue.png);\">
    <div id=\"merchant-carousel\" class=\"carousel slide\" data-ride=\"carousel\">
      <!-- Indicators -->
      <ol class=\"carousel-indicators\">
        <li data-target=\"#merchant-carousel\" data-slide-to=\"0\" class=\"active\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"1\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"2\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"3\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"4\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"5\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"6\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"7\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"8\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"9\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"10\"></li>
      </ol>

      <!-- Wrapper for slides -->
      <div class=\"container iq-mb-30\">
        <div class=\"carousel-inner\" role=\"listbox\">
          <div class=\"item active\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 423
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/m1.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 1</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Install Aplikasi Merchant - yap! dari Play Store gadget Kamu. Selanjutnya Buka Aplikasi dan Klik DAFTAR
                  </h5>
                  <p>&nbsp;</p>
                  <div class=\"iq-fancy-box-05\">

                    <a class=\"iq-mr-15\" href=\"https://play.google.com/store/apps/details?id=id.co.bni.yapmerchant&hl=in\"><img src=\"";
        // line 433
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/Playstore_Badge.png\" alt=\"Playstore\"></a>

                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- 2 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 446
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/m2.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 2</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Setelah itu buka Aplikasi dan kamu akan menemukan keterangan User agreement. Baca dan pahami seluruh syarat dan ketentuan yap! \000</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 3 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 462
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/m3.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 3</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Kalau sudah, ceklist, dan OK pada User Agreement.</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 4 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 478
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/m4.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 4</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Silahkan pilih Bahasa sesuai keinginan kamu. IND untuk Bahasa Indonesia dan ENG untuk Bahasa Inggris. Kemudian lanjut.
                  </h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 6 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 495
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/m5.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 5</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Isi seluruh informasi merchant kamu.
                  </h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 7 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 512
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/m6.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 6</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Isi seluruh informasi merchant kamu.</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 8 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 528
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/m7.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 7</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Isi data MID kamu sesuai dengan informasi yang diberikan oleh petugas bank.
                  </h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 9 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 545
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/m8.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 8</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Kata sandi minimal 6 digit, case sensitive (kombinasi huruf besar, huruf kecil, dan angka)</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 10 -->

          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"";
        // line 562
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/m9.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 9
                  </h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Kamu telah menjadi merchant yap! Selamat bertransaksi.
                  </h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class=\"small-only\">
    <div class=\"container\">
      <div class=\"row\">
        <div id=\"merchant-small-carousel\" class=\"tutorial\">
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 584
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/m1.png\" alt=\"\">
            <h4>Step 1</h4>
            <p>Install Aplikasi Merchant - yap! dari Play Store gadget Kamu. Selanjutnya Buka Aplikasi dan Klik DAFTAR</p>
            <a href=\"https://play.google.com/store/apps/details?id=id.co.bni.yapmerchant&hl=in\"><img src=\"";
        // line 587
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/Playstore_Badge.png\" alt=\"Playstore\"></a>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 590
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/m2.png\" alt=\"\">
            <h4>Step 2</h4>
            <p>Setelah itu buka Aplikasi dan kamu akan menemukan keterangan User agreement. Baca dan pahami seluruh syarat dan ketentuan yap!</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 595
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/m3.png\" alt=\"\">
            <h4>Step 3</h4>
            <p>Kalau sudah, ceklist, dan OK pada User Agreement.</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 600
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/m4.png\" alt=\"\">
            <h4>Step 4</h4>
            <p>Silahkan pilih Bahasa sesuai keinginan kamu. IND untuk Bahasa Indonesia dan ENG untuk Bahasa Inggris. Kemudian lanjut.</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 605
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/m5.png\" alt=\"\">
            <h4>Step 5</h4>
            <p>Isi seluruh informasi merchant kamu.</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 610
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/m6.png\" alt=\"\">
            <h4>Step 6</h4>
            <p>Isi seluruh informasi merchant kamu.</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 615
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/m7.png\" alt=\"\">
            <h4>Step 7</h4>
            <p>Isi data MID kamu sesuai dengan informasi yang diberikan oleh petugas bank.</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 620
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/m8.png\" alt=\"\">
            <h4>Step 8</h4>
            <p>Kata sandi minimal 6 digit, case sensitive (kombinasi huruf besar, huruf kecil, dan angka)</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"";
        // line 625
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/m9.png\" alt=\"\">
            <h4>Step 9</h4>
            <p>Kamu telah menjadi merchant yap! Selamat bertransaksi.</p>
          </div>

        </div>
      </div>
    </div>
  </section>

  <section id=\"blog\" class=\"overview-block-ptb white-bg iq-blog\">
    <div class=\"container\">
      <div class=\"row\">
        <div class=\"col-sm-12\">
          <div class=\"heading-title\">
            <h2 class=\"title iq-tw-6\">Merchant yap!</h2>
            <div class=\"divider\"></div>
            <!--p>Jangan sampai terlewat, selalu cek berbagai promo dan informasi terbaru mengenai yap! di sini.</p-->
          </div>
        </div>
      </div>
    </div>

    <div class=\"container\">
      <div class=\"row\">
        <div class=\"col-lg-12 col-md-12\">
          <div class=\"owl-carousel\" data-nav-dots=\"false\" data-nav-arrow=\"true\" data-items=\"5\" data-sm-items=\"3\" data-lg-items=\"5\" data-md-items=\"4\" data-autoplay=\"true\">
            <div class=\"item\"><img class=\"img-responsive center-block\" <img src=\"";
        // line 652
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/merchant1.png\" alt=\"#\"></div>
            <div class=\"item\"><img class=\"img-responsive center-block\" <img src=\"";
        // line 653
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/merchant2.png\" alt=\"#\"></div>
            <div class=\"item\"><img class=\"img-responsive center-block\" <img src=\"";
        // line 654
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/merchant3.png\" alt=\"#\"></div>
            <div class=\"item\"><img class=\"img-responsive center-block\" <img src=\"";
        // line 655
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/merchant4.png\" alt=\"#\"></div>
            <div class=\"item\"><img class=\"img-responsive center-block\" <img src=\"";
        // line 656
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/merchant5.png\" alt=\"#\"></div>
            <div class=\"item\"><img class=\"img-responsive center-block\" <img src=\"";
        // line 657
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/merchant6.png\" alt=\"#\"></div>
            <div class=\"item\"><img class=\"img-responsive center-block\" <img src=\"";
        // line 658
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/merchant7.png\" alt=\"#\"></div>
          </div>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <center>
            <a class=\"button iq-mt-15\" href=\"#\">Daftar Semua Merchant</a>
          </center>
        </div>
      </div>

    </div>

  </section>

";
    }

    // line 674
    public function block_customJS($context, array $blocks = array())
    {
        // line 675
        echo "<script type=\"text/javascript\">
  \$(function() {
    \$('#customer-small-carousel, #merchant-small-carousel').slick({
      dots: true,
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: true,
      autoplaySpeed: 5000,
      arrows: false
    });
  });
</script>
";
    }

    public function getTemplateName()
    {
        return "client/support.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  873 => 675,  870 => 674,  851 => 658,  847 => 657,  843 => 656,  839 => 655,  835 => 654,  831 => 653,  827 => 652,  797 => 625,  789 => 620,  781 => 615,  773 => 610,  765 => 605,  757 => 600,  749 => 595,  741 => 590,  735 => 587,  729 => 584,  704 => 562,  684 => 545,  664 => 528,  645 => 512,  625 => 495,  605 => 478,  586 => 462,  567 => 446,  551 => 433,  538 => 423,  510 => 398,  483 => 374,  475 => 369,  467 => 364,  459 => 359,  451 => 354,  443 => 349,  435 => 344,  427 => 339,  419 => 334,  411 => 329,  405 => 326,  399 => 323,  377 => 304,  358 => 288,  339 => 272,  320 => 256,  301 => 240,  282 => 224,  263 => 208,  244 => 192,  225 => 176,  206 => 160,  190 => 147,  178 => 138,  151 => 114,  65 => 31,  61 => 29,  42 => 5,  39 => 4,  36 => 3,  30 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layouts/layout.html.twig' %}
{% block title %}Dukungan{% endblock %}
{% block content %}
  <!-- Frequently Asked Questions -->
  <section id=\"support\" class=\"overview-block-ptb banner iq-bg iq-bg-fixed iq-box-shadow\" style=\" background: url({{ app.request.basepath }}/public/assets/img/header_blue.png);\">
    <div id=\"carousel-example-generic\" class=\"carousel slide\" data-ride=\"carousel\">
      <div class=\"container\">
        <div class=\"row\">
          <div class=\"col-sm-12\">
            <div class=\"heading-title\">
              <h2 class=\"title iq-tw-6\">Mekanisme Aplikasi yap! Bagi Customer</h2>
              <div class=\"divider\"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section id=\"mekanism\" class=\"overview-block-ptb\">
    <div class=\"container\">
      {# <div class=\"row\">
                <div class=\"col-sm-12 col-md-12 col-lg-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">Mekanisme Aplikasi yap!</h2>
                        <div class=\"divider\"></div>
                    </div>
                </div>
            </div> #}
      <div class=\"row\">
        <div class=\"col-sm-12 col-md-6 col-lg-6\">
          <img src=\"{{ app.request.basepath }}/public/assets/img/infografik.png\" alt=\"\" class=\"img-responsive infografik\">
        </div>
        <div class=\"col-sm-12 col-md-6 col-lg-6 mt-sm\">
          <div class=\"row step iq-mb-15\">
            <div class=\"col-xs-2 h72\">
              <div class=\"iq-icon magical\">
                1
              </div>
            </div>
            <div class=\"col-xs-10 tc\">
              <span class=\"magical\">Nasabah/Customer datang ke merchant</span>
            </div>
          </div>
          <div class=\"row step iq-mb-15\">
            <div class=\"col-xs-2 h72\">
              <div class=\"iq-icon magical\">
                2
              </div>
            </div>
            <div class=\"col-xs-10 tc\">
              <span class=\"magical\">Merchant menampilkan QR Code sebagai media untuk transaksi</span>
            </div>
          </div>
          <div class=\"row step iq-mb-15\">
            <div class=\"col-xs-2 h72\">
              <div class=\"iq-icon magical\">
                3
              </div>
            </div>
            <div class=\"col-xs-10 tc\">
              <span class=\"magical\">Nasabah/Customer login ke yap!</span>
            </div>
          </div>
          <div class=\"row step iq-mb-15\">
            <div class=\"col-xs-2 h72\">
              <div class=\"iq-icon magical\">
                4
              </div>
            </div>
            <div class=\"col-xs-10 tc\">
              <span class=\"magical\">Nasabah/Customer melakukan scanning QR Code, input nominal transaksi dan Pin Kartu Kredit yang divalidasi oleh host Bank.</span>
            </div>
          </div>
          <div class=\"row step iq-mb-15\">
            <div class=\"col-xs-2 h72\">
              <div class=\"iq-icon magical\">
                5
              </div>
            </div>
            <div class=\"col-xs-10 tc\">
              <span class=\"magical\">Transaksi berhasil. Notifikasi transaksi akan dikirimkan ke nasabah dan merchant</span>
            </div>
          </div>
          <div class=\"row step iq-mb-15\">
            <div class=\"col-xs-2 h72\">
              <div class=\"iq-icon magical\">
                6
              </div>
            </div>
            <div class=\"col-xs-10 tc\">
              <span class=\"magical\">Transaksi Berhasil</span>
            </div>
          </div>
          <div class=\"jumbotron\">
            <h5>Penggunaan 6 Digit PIN merupakan pemenuhan SEBI No. 16/25/DKSP/ Tanggal 31 Desember 2014</h5>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section>
    <div class=\"container\">
      <div class=\"row\">
        <div class=\"col-sm-12\">
          <div class=\"heading-title\">
            <h2 class=\"title iq-tw-6\">Cara Menggunakan yap! bagi Customer</h2>
            <div class=\"divider\"></div>
            <!-- <p>YAP! adalah aplikasi yang menjadikan pembayaran menjadi lebih mudah. Banyak manfaat yang bisa anda dapatkan ketika mnejadikan YAP! bagian dari hidup anda.</p> -->
          </div>
        </div>
      </div>
    </div>
  </section>
  <section id=\"iq-home\" class=\"banner iq-bg iq-bg-fixed iq-box-shadow large-only\" style=\" background: url({{app.request.basepath}}/public/assets/img/header_blue.png);\">
    <div id=\"main-carousel\" class=\"carousel slide\" data-ride=\"carousel\">
      <!-- Indicators -->
      <ol class=\"carousel-indicators\">
        <li data-target=\"#main-carousel\" data-slide-to=\"0\" class=\"active\"></li>
        <li data-target=\"#main-carousel\" data-slide-to=\"1\"></li>
        <li data-target=\"#main-carousel\" data-slide-to=\"2\"></li>
        <li data-target=\"#main-carousel\" data-slide-to=\"3\"></li>
        <li data-target=\"#main-carousel\" data-slide-to=\"4\"></li>
        <li data-target=\"#main-carousel\" data-slide-to=\"5\"></li>
        <li data-target=\"#main-carousel\" data-slide-to=\"6\"></li>
        <li data-target=\"#main-carousel\" data-slide-to=\"7\"></li>
        <li data-target=\"#main-carousel\" data-slide-to=\"8\"></li>

      </ol>

      <!-- Wrapper for slides -->
      <div class=\"container iq-mb-30\">
        <div class=\"carousel-inner\" role=\"listbox\">
          <div class=\"item active\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/step/transact/1.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 1</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Install Aplikasi yap! dari Play Store gadget Kamu.</h5>
                  <p>&nbsp;</p>
                  <div class=\"iq-fancy-box-05\">

                    <a class=\"iq-mr-15\" href=\"https://play.google.com/store/apps/details?id=id.co.bni.yapcustomer\"><img src=\"{{ app.request.basepath }}/public/assets/img/Playstore_Badge.png\" alt=\"Playstore\"></a>

                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- 2 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/step/transact/2.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 2</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Setelah itu buka Aplikasi dan kamu akan menemukan keterangan User agreement</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 3 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/step/transact/3.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 3</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Muncul keterangan keamanan, pilih NEXT</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 4 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/step/transact/4.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 4</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Masukkan data Identitas kamu sesuai dengan form yang tersedia. jangan lupa membuat password untuk akses aplikasi yap!</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 6 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/step/transact/5.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 5</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Ketika data sudah lengkap, kamu akan menerima informasi sukses. lanjutkan dengan melakukan login.</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 7 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/step/transact/6.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 6</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Kamu akan masuk ke halaman login, masukkan user dan password yang telah dibuat</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 8 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/step/transact/7.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 7</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Selanjutnya akan masuk ke proses pemilihan kartu yang akan digunakan untuk transaksi / aktivasi yap!. Bisa pilih Kartu Debit, Kartu Kredit atau UNIKQU.</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 9 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/step/transact/8.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 8</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Kemudian masukkan Nomer ID Kartu atau Akun UNIKQU</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 10 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/step/transact/9.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 9</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Masukkan UNIKQU PIN yang sudah tersedia di akun UNIKQU kamu.</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 11 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/step/transact/10.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 10</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Kode OTP akan dikirim melalui SMS ke Nomor yang sudah terdaftar. masukkan ke Kolom Kode OTP.</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 12 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/step/transact/11.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 11</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Akun yap! kamu sudah bisa digunakan.</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class=\"small-only\">
    <div class=\"container\">
      <div class=\"row\">
        <div id=\"customer-small-carousel\" class=\"tutorial\">
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/step/transact/1.png\" alt=\"\">
            <h4>Step 1</h4>
            <p>Install Aplikasi yap! dari Play Store gadget Kamu.</p>
            <a href=\"https://play.google.com/store/apps/details?id=id.co.bni.yapcustomer\"><img src=\"{{ app.request.basepath }}/public/assets/img/Playstore_Badge.png\" alt=\"Playstore\"></a>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/step/transact/2.png\" alt=\"\">
            <h4>Step 2</h4>
            <p>Setelah itu buka Aplikasi dan kamu akan menemukan keterangan User agreement</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/step/transact/3.png\" alt=\"\">
            <h4>Step 3</h4>
            <p>Muncul keterangan keamanan, pilih NEXT</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/step/transact/4.png\" alt=\"\">
            <h4>Step 4</h4>
            <p>Masukkan data Identitas kamu sesuai dengan form yang tersedia. jangan lupa membuat password untuk akses aplikasi yap!</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/step/transact/5.png\" alt=\"\">
            <h4>Step 5</h4>
            <p>Ketika data sudah lengkap, kamu akan menerima informasi sukses. lanjutkan dengan melakukan login.</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/step/transact/6.png\" alt=\"\">
            <h4>Step 6</h4>
            <p>Kamu akan masuk ke halaman login, masukkan user dan password yang telah dibuat</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/step/transact/7.png\" alt=\"\">
            <h4>Step 7</h4>
            <p>Selanjutnya akan masuk ke proses pemilihan kartu yang akan digunakan untuk transaksi / aktivasi yap!. Bisa pilih Kartu Debit, Kartu Kredit atau UNIKQU.</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/step/transact/8.png\" alt=\"\">
            <h4>Step 8</h4>
            <p>Kemudian masukkan Nomer ID Kartu atau Akun UNIKQU</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/step/transact/9.png\" alt=\"\">
            <h4>Step 9</h4>
            <p>Masukkan UNIKQU PIN yang sudah tersedia di akun UNIKQU kamu.</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/step/transact/10.png\" alt=\"\">
            <h4>Step 10</h4>
            <p>Kode OTP akan dikirim melalui SMS ke Nomor yang sudah terdaftar. masukkan ke Kolom Kode OTP.</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/step/transact/11.png\" alt=\"\">
            <h4>Step 11</h4>
            <p>Akun yap! kamu sudah bisa digunakan.</p>
          </div>
        </div>
      </div>
    </div>
  </section>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <section>
    <div class=\"container\">
      <div class=\"row\">
        <div class=\"col-sm-12\">
          <div class=\"heading-title\">
            <h2 class=\"title iq-tw-6\">Cara Menggunakan yap! bagi Merchant</h2>
            <div class=\"divider\"></div>
            <!-- <p>YAP! adalah aplikasi yang menjadikan pembayaran menjadi lebih mudah. Banyak manfaat yang bisa anda dapatkan ketika mnejadikan YAP! bagian dari hidup anda.</p> -->
          </div>
        </div>
      </div>
    </div>
  </section>
  <section id=\"iq-home\" class=\"banner iq-bg iq-bg-fixed iq-box-shadow large-only\" style=\" background: url({{app.request.basepath}}/public/assets/img/header_blue.png);\">
    <div id=\"merchant-carousel\" class=\"carousel slide\" data-ride=\"carousel\">
      <!-- Indicators -->
      <ol class=\"carousel-indicators\">
        <li data-target=\"#merchant-carousel\" data-slide-to=\"0\" class=\"active\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"1\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"2\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"3\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"4\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"5\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"6\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"7\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"8\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"9\"></li>
        <li data-target=\"#merchant-carousel\" data-slide-to=\"10\"></li>
      </ol>

      <!-- Wrapper for slides -->
      <div class=\"container iq-mb-30\">
        <div class=\"carousel-inner\" role=\"listbox\">
          <div class=\"item active\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/m1.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 1</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Install Aplikasi Merchant - yap! dari Play Store gadget Kamu. Selanjutnya Buka Aplikasi dan Klik DAFTAR
                  </h5>
                  <p>&nbsp;</p>
                  <div class=\"iq-fancy-box-05\">

                    <a class=\"iq-mr-15\" href=\"https://play.google.com/store/apps/details?id=id.co.bni.yapmerchant&hl=in\"><img src=\"{{ app.request.basepath }}/public/assets/img/Playstore_Badge.png\" alt=\"Playstore\"></a>

                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- 2 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/m2.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 2</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Setelah itu buka Aplikasi dan kamu akan menemukan keterangan User agreement. Baca dan pahami seluruh syarat dan ketentuan yap! \000</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 3 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/m3.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 3</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Kalau sudah, ceklist, dan OK pada User Agreement.</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 4 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/m4.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 4</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Silahkan pilih Bahasa sesuai keinginan kamu. IND untuk Bahasa Indonesia dan ENG untuk Bahasa Inggris. Kemudian lanjut.
                  </h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 6 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/m5.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 5</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Isi seluruh informasi merchant kamu.
                  </h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 7 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/m6.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 6</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Isi seluruh informasi merchant kamu.</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 8 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/m7.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 7</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Isi data MID kamu sesuai dengan informasi yang diberikan oleh petugas bank.
                  </h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 9 -->
          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/m8.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 8</h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Kata sandi minimal 6 digit, case sensitive (kombinasi huruf besar, huruf kecil, dan angka)</h5>
                </div>
              </div>
            </div>
          </div>
          <!-- 10 -->

          <div class=\"item\">
            <div class=\"banner-text\">
              <div class=\"row\">
                <div class=\"col-sm-4 col-lg-4 col-md-4 hidden-xs\">
                  <div class=\"img-one pull-left\">
                    <img class=\"img-responsive center-block\" data-animation=\"animated fadeInLeft\" src=\"{{app.request.basepath}}/public/assets/img/m9.png\" alt=\"#\">
                  </div>
                </div>
                <div class=\"col-sm-8 col-lg-8 col-md-8 inner-text iq-pr-80\">
                  <h3 class=\"iq-font-white iq-tw-8\" data-animation=\"animated fadeInRight\">Step 9
                  </h3>
                  <h5 class=\"iq-mt-20 iq-font-white\">Kamu telah menjadi merchant yap! Selamat bertransaksi.
                  </h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class=\"small-only\">
    <div class=\"container\">
      <div class=\"row\">
        <div id=\"merchant-small-carousel\" class=\"tutorial\">
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/m1.png\" alt=\"\">
            <h4>Step 1</h4>
            <p>Install Aplikasi Merchant - yap! dari Play Store gadget Kamu. Selanjutnya Buka Aplikasi dan Klik DAFTAR</p>
            <a href=\"https://play.google.com/store/apps/details?id=id.co.bni.yapmerchant&hl=in\"><img src=\"{{ app.request.basepath }}/public/assets/img/Playstore_Badge.png\" alt=\"Playstore\"></a>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/m2.png\" alt=\"\">
            <h4>Step 2</h4>
            <p>Setelah itu buka Aplikasi dan kamu akan menemukan keterangan User agreement. Baca dan pahami seluruh syarat dan ketentuan yap!</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/m3.png\" alt=\"\">
            <h4>Step 3</h4>
            <p>Kalau sudah, ceklist, dan OK pada User Agreement.</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/m4.png\" alt=\"\">
            <h4>Step 4</h4>
            <p>Silahkan pilih Bahasa sesuai keinginan kamu. IND untuk Bahasa Indonesia dan ENG untuk Bahasa Inggris. Kemudian lanjut.</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/m5.png\" alt=\"\">
            <h4>Step 5</h4>
            <p>Isi seluruh informasi merchant kamu.</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/m6.png\" alt=\"\">
            <h4>Step 6</h4>
            <p>Isi seluruh informasi merchant kamu.</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/m7.png\" alt=\"\">
            <h4>Step 7</h4>
            <p>Isi data MID kamu sesuai dengan informasi yang diberikan oleh petugas bank.</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/m8.png\" alt=\"\">
            <h4>Step 8</h4>
            <p>Kata sandi minimal 6 digit, case sensitive (kombinasi huruf besar, huruf kecil, dan angka)</p>
          </div>
          <div class=\"col-sm-6 col-sm-offset-3\">
            <img src=\"{{ app.request.basepath }}/public/assets/img/m9.png\" alt=\"\">
            <h4>Step 9</h4>
            <p>Kamu telah menjadi merchant yap! Selamat bertransaksi.</p>
          </div>

        </div>
      </div>
    </div>
  </section>

  <section id=\"blog\" class=\"overview-block-ptb white-bg iq-blog\">
    <div class=\"container\">
      <div class=\"row\">
        <div class=\"col-sm-12\">
          <div class=\"heading-title\">
            <h2 class=\"title iq-tw-6\">Merchant yap!</h2>
            <div class=\"divider\"></div>
            <!--p>Jangan sampai terlewat, selalu cek berbagai promo dan informasi terbaru mengenai yap! di sini.</p-->
          </div>
        </div>
      </div>
    </div>

    <div class=\"container\">
      <div class=\"row\">
        <div class=\"col-lg-12 col-md-12\">
          <div class=\"owl-carousel\" data-nav-dots=\"false\" data-nav-arrow=\"true\" data-items=\"5\" data-sm-items=\"3\" data-lg-items=\"5\" data-md-items=\"4\" data-autoplay=\"true\">
            <div class=\"item\"><img class=\"img-responsive center-block\" <img src=\"{{ app.request.basepath }}/public/assets/img/merchant1.png\" alt=\"#\"></div>
            <div class=\"item\"><img class=\"img-responsive center-block\" <img src=\"{{ app.request.basepath }}/public/assets/img/merchant2.png\" alt=\"#\"></div>
            <div class=\"item\"><img class=\"img-responsive center-block\" <img src=\"{{ app.request.basepath }}/public/assets/img/merchant3.png\" alt=\"#\"></div>
            <div class=\"item\"><img class=\"img-responsive center-block\" <img src=\"{{ app.request.basepath }}/public/assets/img/merchant4.png\" alt=\"#\"></div>
            <div class=\"item\"><img class=\"img-responsive center-block\" <img src=\"{{ app.request.basepath }}/public/assets/img/merchant5.png\" alt=\"#\"></div>
            <div class=\"item\"><img class=\"img-responsive center-block\" <img src=\"{{ app.request.basepath }}/public/assets/img/merchant6.png\" alt=\"#\"></div>
            <div class=\"item\"><img class=\"img-responsive center-block\" <img src=\"{{ app.request.basepath }}/public/assets/img/merchant7.png\" alt=\"#\"></div>
          </div>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <center>
            <a class=\"button iq-mt-15\" href=\"#\">Daftar Semua Merchant</a>
          </center>
        </div>
      </div>

    </div>

  </section>

{% endblock %}

{% block customJS %}
<script type=\"text/javascript\">
  \$(function() {
    \$('#customer-small-carousel, #merchant-small-carousel').slick({
      dots: true,
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: true,
      autoplaySpeed: 5000,
      arrows: false
    });
  });
</script>
{% endblock %}
", "client/support.html.twig", "/Users/macos/Projects/yap_v3/src/Templates/client/support.html.twig");
    }
}
