<?php

/* layouts/layout.html.twig */
class __TwigTemplate_2c7c61030f70752f9557ef3b460a9d0da1036d5119a51fd01f8e83e6e004b491 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
            'customJS' => array($this, 'block_customJS'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\" />
        <title>YAP! - ";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <!-- Favicon -->
        <link rel=\"shortcut icon\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/logo_yap2.png\" />
        <!-- Google Fonts -->
        <link rel=\"stylesheet\" type=\"text/css\" href=\"https://fonts.googleapis.com/css?family=Open+Sans:400,600,700&amp;Raleway:300,400,500,600,700,800,900\">
        <!-- Bootstrap -->
        <link rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/bootstrap.min.css\">
        <!-- owl-carousel -->
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/owl-carousel/owl.carousel.css\" />
        <!-- Font Awesome -->
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/font-awesome.css\" />
        <!-- Magnific Popup -->
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/magnific-popup/magnific-popup.css\" />
        <!-- Animate -->
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/animate.css\" />
        <!-- Ionicons -->
        <link rel=\"stylesheet\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/ionicons.min.css\">
        <link rel=\"stylesheet\" href=\"//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/3.1.4/css/bootstrap-datetimepicker.min.css\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/slick.css\"/>
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/slick-theme.css\"/>
        <!-- Style -->
        <link rel=\"stylesheet\" href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/style.css\">
        <!-- Responsive -->
        <link rel=\"stylesheet\" href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/responsive.css\">
        <!-- custom style -->
        <link rel=\"stylesheet\" href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/custom.css\" />
    </head>
    <body>
        <!-- loading -->
        <div id=\"loading\" class=\"green-bg\">
            <div id=\"loading-center\">
                <div class=\"boxLoading\"></div>
            </div>
        </div>
        <!-- loading End -->
        <!-- Header -->
        <header id=\"header-wrap\" data-spy=\"affix\" data-offset-top=\"55\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-sm-12\">
                        <nav class=\"navbar navbar-default\">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class=\"navbar-header\">
                                <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">
                                <span class=\"sr-only\">Toggle navigation</span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                                </button>
                                <a class=\"navbar-brand\" href=\"";
        // line 56
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("home");
        echo "\">
                                    <span><img src=\"";
        // line 57
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/Logo_YAP.png\" alt=\"logo\"></span>
                                </a>
                            </div>
                            <!-- Collect the nav links, forms, and other content for toggling -->
                            ";
        // line 61
        $context["uriPath"] = $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method"), $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route_params"), "method"));
        // line 62
        echo "                            <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                                <ul class=\"nav navbar-nav\" id=\"top-menu\">
                                    <li ";
        // line 64
        if (((isset($context["uriPath"]) ? $context["uriPath"] : $this->getContext($context, "uriPath")) == $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("about"))) {
            echo "class=\"active\"";
        }
        echo "><a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("about");
        echo "\">Tentang Kami</a></li>
                                    <li ";
        // line 65
        if (((isset($context["uriPath"]) ? $context["uriPath"] : $this->getContext($context, "uriPath")) == $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("support"))) {
            echo "class=\"active\"";
        }
        echo "><a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("support");
        echo "\">Layanan</a></li>
                                    <li ";
        // line 66
        if (((isset($context["uriPath"]) ? $context["uriPath"] : $this->getContext($context, "uriPath")) == $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("event_list"))) {
            echo "class=\"active\"";
        }
        echo "><a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("event_list");
        echo "\">Promo &amp; Blog</a></li>
                                    <!--li ";
        // line 67
        if (((isset($context["uriPath"]) ? $context["uriPath"] : $this->getContext($context, "uriPath")) == $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("contact"))) {
            echo "class=\"active\"";
        }
        echo "><a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("contact");
        echo "\">FAQ</a></li-->
                                    <li class=\"hidden-lg\"><a href=\"";
        // line 68
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("register_merchant");
        echo "\">Bergabung Menjadi Merchant</a></li>
                                    <span class=\"hidden-sm hidden-xs hidden-md\">
                                        <a href=\"";
        // line 70
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("register_merchant");
        echo "\" class=\"btn btn-merchant\">Bergabung Menjadi Merchant</a>


                                        <a href=\"http://www.bni.co.id/id-id/\" class=\"hidden-xs\" target=\"_blank\">
                                            <img src=\"";
        // line 74
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/logo_bni.png\" alt=\"\">
                                        </a>
                                    </span>
                                </ul>
                            </div>
                            <!-- /.navbar-collapse -->
                        </nav>
                    </div>
                </div>
            </div>
        </header>
        <!-- Header End -->
        ";
        // line 86
        $this->displayBlock('content', $context, $blocks);
        // line 87
        echo "        <div class=\"footer\">
            <footer>
                <div class=\"container\">
                    <div class=\"row iq-ptb-40\">
                        <div class=\"col-sm-12 col-md-2 col-lg-2\">
                            <div class=\"iq-fancy-box-04\">
                                <a href=\"";
        // line 93
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("home");
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/logo_yap2.png\" alt=\"\" class=\"img-responsive\"></a>
                            </div>
                        </div>

                        <div class=\"col-sm-12 col-md-3 col-lg-3 iq-mt-15\">
                            <a href=\"https://eform.bni.co.id/BNI_eForm/kartuKredit\" target=\"_blank\">
                                <div class=\"iq-fancy-box-04\">
                                    <div class=\"iq-icon green-bg\">
                                        <i aria-hidden=\"true\" class=\"fa fa-credit-card-alt\"></i>
                                    </div>
                                    <div class=\"fancy-content\">
                                        <p class=\"iq-tw-6\">Apply BNI <br>Credit Card</p>
                                        <!-- <span class=\"lead iq-tw-6\">1234 North Luke Lane, South Bend,IN 360001</span> -->
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class=\"col-sm-12 col-md-3 col-lg-3 iq-mt-15\">
                            <a href=\"https://eform.bni.co.id/BNI_eForm/bukasimpanan\" target=\"_blank\">
                                <div class=\"iq-fancy-box-04\">
                                    <div class=\"iq-icon green-bg\">
                                        <i aria-hidden=\"true\" class=\"fa fa-address-book-o\"></i>
                                    </div>
                                    <div class=\"fancy-content\">
                                        <p class=\"iq-tw-6\">Apply BNI <br> Saving Account</p>
                                        <!-- <span class=\"lead iq-tw-6\">1234 North Luke Lane, South Bend,IN 360001</span> -->
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class=\"col-sm-12 col-md-1 col-lg-1\">&nbsp;</div>
                        <div class=\"col-sm-12 col-md-3 col-lg-3\">

                            </br>
                            <div class=\"iq-fancy-box-05\">

                                    <a class=\"iq-mr-15\" href=\"https://play.google.com/store/apps/details?id=id.co.bni.yapcustomer\"><img src=\"";
        // line 130
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/Playstore_Badge.png\" alt=\"Playstore\" ></a>

                            </div>

                        </div>
                    </div>


                      <div class=\"row iq-footer-03 white-bg iq-pt-20 iq-pb-50\">
                        <div class=\"col-sm-12\">
                            <ul class=\"info-share\">
                                <li><a href=\"http://twitter.com/bni\" target=\"_blank\"><i class=\"fa fa-twitter\"></i></a></li>
                                <li><a href=\"http://facebook.com/bni\" target=\"_blank\"><i class=\"fa fa-facebook\"></i></a></li>
                                <li><a href=\"http://instagram.com/bni46\" target=\"_blank\"><i class=\"fa fa-instagram\"></i></a></li>
                                <li><a href=\"http://www.youtube.com/BNITVC\" target=\"_blank\"><i class=\"fa fa-youtube\"></i></a></li>
                              </br> </br>
                                <li><a href=\"#\" target=\"_blank\"><i class=\"fa fa-phone\"></i></a></li>
                                <a> BNI Call <strong> 1500046 </strong></a>


                            </ul>

                        </div>
                    </div>

                    <div class=\"row iq-footer-03 white-bg iq-pt-20 iq-pb-50\">
                        <div class=\"col-sm-12\">
                            <div class=\"footer-copyright iq-pt-30\">&copy; Hak Cipta <span id=\"copyright\"> <script>document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))</script></span> PT. Bank Negara Indonesia (Persero), Tbk. <span class=\"pull-right\">BNI Terdaftar dan diawasi oleh Otoritas Jasa Keuangan.</span> </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- Footer END -->
        </div>
        <script type=\"text/javascript\" src=\"";
        // line 164
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/jquery.min.js\"></script>
        <!-- bootstrap -->
        <script type=\"text/javascript\" src=\"";
        // line 166
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/bootstrap.min.js\"></script>
        <!-- owl-carousel -->
        <script type=\"text/javascript\" src=\"";
        // line 168
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/owl-carousel/owl.carousel.min.js\"></script>
        <!-- Counter -->
        <script type=\"text/javascript\" src=\"";
        // line 170
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/counter/jquery.countTo.js\"></script>
        <!-- Jquery Appear -->
        <script type=\"text/javascript\" src=\"";
        // line 172
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/jquery.appear.js\"></script>
        <!-- Magnific Popup -->
        <script type=\"text/javascript\" src=\"";
        // line 174
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/magnific-popup/jquery.magnific-popup.min.js\"></script>
        <!-- Retina -->
        <script type=\"text/javascript\" src=\"";
        // line 176
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/retina.min.js\"></script>
        <!-- wow -->
        <script type=\"text/javascript\" src=\"";
        // line 178
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/wow.min.js\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 179
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/skrollr.min.js\"></script>
        <!-- Countdown -->
        <script type=\"text/javascript\" src=\"";
        // line 181
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/jquery.countdown.min.js\"></script>
        <script src=\"//cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.19.2/moment.min.js\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/3.1.4/js/bootstrap-datetimepicker.min.js\"></script>
        <script src=\"https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=5br0ypa84o2fxnc4mca8ux1bcrx68ubstyj7wcw4k5wm3s5x\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 186
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/slick.min.js\"></script>
        <!-- Custom -->
        <script type=\"text/javascript\" src=\"";
        // line 188
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/custom.js\"></script>
        <!-- Style Customizer -->
        ";
        // line 191
        echo "        <!--Start of Tawk.to Script-->
<script type=\"text/javascript\">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement(\"script\"),s0=document.getElementsByTagName(\"script\")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5a6380a24b401e45400c408b/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
    ";
        // line 204
        $this->displayBlock('customJS', $context, $blocks);
        // line 205
        echo "    </body>
</html>
";
    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
    }

    // line 86
    public function block_content($context, array $blocks = array())
    {
    }

    // line 204
    public function block_customJS($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "layouts/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  378 => 204,  373 => 86,  368 => 6,  362 => 205,  360 => 204,  345 => 191,  340 => 188,  335 => 186,  327 => 181,  322 => 179,  318 => 178,  313 => 176,  308 => 174,  303 => 172,  298 => 170,  293 => 168,  288 => 166,  283 => 164,  246 => 130,  204 => 93,  196 => 87,  194 => 86,  179 => 74,  172 => 70,  167 => 68,  159 => 67,  151 => 66,  143 => 65,  135 => 64,  131 => 62,  129 => 61,  122 => 57,  118 => 56,  91 => 32,  86 => 30,  81 => 28,  76 => 26,  72 => 25,  66 => 22,  61 => 20,  56 => 18,  51 => 16,  46 => 14,  41 => 12,  34 => 8,  29 => 6,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\" />
        <title>YAP! - {% block title %}{% endblock %}</title>
        <!-- Favicon -->
        <link rel=\"shortcut icon\" href=\"{{ app.request.basepath }}/public/assets/img/logo_yap2.png\" />
        <!-- Google Fonts -->
        <link rel=\"stylesheet\" type=\"text/css\" href=\"https://fonts.googleapis.com/css?family=Open+Sans:400,600,700&amp;Raleway:300,400,500,600,700,800,900\">
        <!-- Bootstrap -->
        <link rel=\"stylesheet\" href=\"{{ app.request.basepath }}/public/assets/css/bootstrap.min.css\">
        <!-- owl-carousel -->
        <link rel=\"stylesheet\" type=\"text/css\" href=\"{{ app.request.basepath }}/public/assets/css/owl-carousel/owl.carousel.css\" />
        <!-- Font Awesome -->
        <link rel=\"stylesheet\" type=\"text/css\" href=\"{{ app.request.basepath }}/public/assets/css/font-awesome.css\" />
        <!-- Magnific Popup -->
        <link rel=\"stylesheet\" type=\"text/css\" href=\"{{ app.request.basepath }}/public/assets/css/magnific-popup/magnific-popup.css\" />
        <!-- Animate -->
        <link rel=\"stylesheet\" type=\"text/css\" href=\"{{ app.request.basepath }}/public/assets/css/animate.css\" />
        <!-- Ionicons -->
        <link rel=\"stylesheet\" href=\"{{ app.request.basepath }}/public/assets/css/ionicons.min.css\">
        <link rel=\"stylesheet\" href=\"//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/3.1.4/css/bootstrap-datetimepicker.min.css\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"{{ app.request.basepath }}/public/assets/css/slick.css\"/>
        <link rel=\"stylesheet\" type=\"text/css\" href=\"{{ app.request.basepath }}/public/assets/css/slick-theme.css\"/>
        <!-- Style -->
        <link rel=\"stylesheet\" href=\"{{ app.request.basepath }}/public/assets/css/style.css\">
        <!-- Responsive -->
        <link rel=\"stylesheet\" href=\"{{ app.request.basepath }}/public/assets/css/responsive.css\">
        <!-- custom style -->
        <link rel=\"stylesheet\" href=\"{{ app.request.basepath }}/public/assets/css/custom.css\" />
    </head>
    <body>
        <!-- loading -->
        <div id=\"loading\" class=\"green-bg\">
            <div id=\"loading-center\">
                <div class=\"boxLoading\"></div>
            </div>
        </div>
        <!-- loading End -->
        <!-- Header -->
        <header id=\"header-wrap\" data-spy=\"affix\" data-offset-top=\"55\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-sm-12\">
                        <nav class=\"navbar navbar-default\">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class=\"navbar-header\">
                                <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">
                                <span class=\"sr-only\">Toggle navigation</span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                                </button>
                                <a class=\"navbar-brand\" href=\"{{ path('home') }}\">
                                    <span><img src=\"{{ app.request.basepath }}/public/assets/img/Logo_YAP.png\" alt=\"logo\"></span>
                                </a>
                            </div>
                            <!-- Collect the nav links, forms, and other content for toggling -->
                            {% set uriPath = path(app.request.attributes.get('_route'), app.request.attributes.get('_route_params')) %}
                            <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                                <ul class=\"nav navbar-nav\" id=\"top-menu\">
                                    <li {% if uriPath == path('about') %}class=\"active\"{% endif %}><a href=\"{{ path('about') }}\">Tentang Kami</a></li>
                                    <li {% if uriPath == path('support') %}class=\"active\"{% endif %}><a href=\"{{ path('support') }}\">Layanan</a></li>
                                    <li {% if uriPath == path('event_list') %}class=\"active\"{% endif %}><a href=\"{{ path('event_list') }}\">Promo &amp; Blog</a></li>
                                    <!--li {% if uriPath == path('contact') %}class=\"active\"{% endif %}><a href=\"{{ path('contact') }}\">FAQ</a></li-->
                                    <li class=\"hidden-lg\"><a href=\"{{ path('register_merchant') }}\">Bergabung Menjadi Merchant</a></li>
                                    <span class=\"hidden-sm hidden-xs hidden-md\">
                                        <a href=\"{{ path('register_merchant') }}\" class=\"btn btn-merchant\">Bergabung Menjadi Merchant</a>


                                        <a href=\"http://www.bni.co.id/id-id/\" class=\"hidden-xs\" target=\"_blank\">
                                            <img src=\"{{ app.request.basepath }}/public/assets/img/logo_bni.png\" alt=\"\">
                                        </a>
                                    </span>
                                </ul>
                            </div>
                            <!-- /.navbar-collapse -->
                        </nav>
                    </div>
                </div>
            </div>
        </header>
        <!-- Header End -->
        {% block content %}{% endblock %}
        <div class=\"footer\">
            <footer>
                <div class=\"container\">
                    <div class=\"row iq-ptb-40\">
                        <div class=\"col-sm-12 col-md-2 col-lg-2\">
                            <div class=\"iq-fancy-box-04\">
                                <a href=\"{{ path('home')}}\"><img src=\"{{ app.request.basepath }}/public/assets/img/logo_yap2.png\" alt=\"\" class=\"img-responsive\"></a>
                            </div>
                        </div>

                        <div class=\"col-sm-12 col-md-3 col-lg-3 iq-mt-15\">
                            <a href=\"https://eform.bni.co.id/BNI_eForm/kartuKredit\" target=\"_blank\">
                                <div class=\"iq-fancy-box-04\">
                                    <div class=\"iq-icon green-bg\">
                                        <i aria-hidden=\"true\" class=\"fa fa-credit-card-alt\"></i>
                                    </div>
                                    <div class=\"fancy-content\">
                                        <p class=\"iq-tw-6\">Apply BNI <br>Credit Card</p>
                                        <!-- <span class=\"lead iq-tw-6\">1234 North Luke Lane, South Bend,IN 360001</span> -->
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class=\"col-sm-12 col-md-3 col-lg-3 iq-mt-15\">
                            <a href=\"https://eform.bni.co.id/BNI_eForm/bukasimpanan\" target=\"_blank\">
                                <div class=\"iq-fancy-box-04\">
                                    <div class=\"iq-icon green-bg\">
                                        <i aria-hidden=\"true\" class=\"fa fa-address-book-o\"></i>
                                    </div>
                                    <div class=\"fancy-content\">
                                        <p class=\"iq-tw-6\">Apply BNI <br> Saving Account</p>
                                        <!-- <span class=\"lead iq-tw-6\">1234 North Luke Lane, South Bend,IN 360001</span> -->
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class=\"col-sm-12 col-md-1 col-lg-1\">&nbsp;</div>
                        <div class=\"col-sm-12 col-md-3 col-lg-3\">

                            </br>
                            <div class=\"iq-fancy-box-05\">

                                    <a class=\"iq-mr-15\" href=\"https://play.google.com/store/apps/details?id=id.co.bni.yapcustomer\"><img src=\"{{ app.request.basepath }}/public/assets/img/Playstore_Badge.png\" alt=\"Playstore\" ></a>

                            </div>

                        </div>
                    </div>


                      <div class=\"row iq-footer-03 white-bg iq-pt-20 iq-pb-50\">
                        <div class=\"col-sm-12\">
                            <ul class=\"info-share\">
                                <li><a href=\"http://twitter.com/bni\" target=\"_blank\"><i class=\"fa fa-twitter\"></i></a></li>
                                <li><a href=\"http://facebook.com/bni\" target=\"_blank\"><i class=\"fa fa-facebook\"></i></a></li>
                                <li><a href=\"http://instagram.com/bni46\" target=\"_blank\"><i class=\"fa fa-instagram\"></i></a></li>
                                <li><a href=\"http://www.youtube.com/BNITVC\" target=\"_blank\"><i class=\"fa fa-youtube\"></i></a></li>
                              </br> </br>
                                <li><a href=\"#\" target=\"_blank\"><i class=\"fa fa-phone\"></i></a></li>
                                <a> BNI Call <strong> 1500046 </strong></a>


                            </ul>

                        </div>
                    </div>

                    <div class=\"row iq-footer-03 white-bg iq-pt-20 iq-pb-50\">
                        <div class=\"col-sm-12\">
                            <div class=\"footer-copyright iq-pt-30\">&copy; Hak Cipta <span id=\"copyright\"> <script>document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))</script></span> PT. Bank Negara Indonesia (Persero), Tbk. <span class=\"pull-right\">BNI Terdaftar dan diawasi oleh Otoritas Jasa Keuangan.</span> </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- Footer END -->
        </div>
        <script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/jquery.min.js\"></script>
        <!-- bootstrap -->
        <script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/bootstrap.min.js\"></script>
        <!-- owl-carousel -->
        <script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/owl-carousel/owl.carousel.min.js\"></script>
        <!-- Counter -->
        <script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/counter/jquery.countTo.js\"></script>
        <!-- Jquery Appear -->
        <script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/jquery.appear.js\"></script>
        <!-- Magnific Popup -->
        <script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/magnific-popup/jquery.magnific-popup.min.js\"></script>
        <!-- Retina -->
        <script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/retina.min.js\"></script>
        <!-- wow -->
        <script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/wow.min.js\"></script>
        <script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/skrollr.min.js\"></script>
        <!-- Countdown -->
        <script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/jquery.countdown.min.js\"></script>
        <script src=\"//cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.19.2/moment.min.js\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/3.1.4/js/bootstrap-datetimepicker.min.js\"></script>
        <script src=\"https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=5br0ypa84o2fxnc4mca8ux1bcrx68ubstyj7wcw4k5wm3s5x\"></script>
        <script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/slick.min.js\"></script>
        <!-- Custom -->
        <script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/custom.js\"></script>
        <!-- Style Customizer -->
        {#<script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/style-customizer.js\"></script>#}
        <!--Start of Tawk.to Script-->
<script type=\"text/javascript\">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement(\"script\"),s0=document.getElementsByTagName(\"script\")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5a6380a24b401e45400c408b/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
    {% block customJS %}{% endblock %}
    </body>
</html>
", "layouts/layout.html.twig", "/Users/macos/Projects/yap_v3/src/Templates/layouts/layout.html.twig");
    }
}
