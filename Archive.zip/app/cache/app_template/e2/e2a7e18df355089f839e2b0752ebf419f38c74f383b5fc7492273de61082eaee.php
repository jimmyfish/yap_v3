<?php

/* home/index.html.twig */
class __TwigTemplate_ed39c59183afddc3dda66583837dfb6e76e826d98d9d794cc6b2abf1f49a4b4c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html.twig", "home/index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Beranda";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "<!-- Banner -->

<section id=\"iq-home\" class=\"banner iq-bg iq-bg-fixed iq-box-shadow\" style=\" background: url(";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/header_blue.png);\">
    <div id=\"carousel-example-generic\" class=\"carousel slide\" data-ride=\"carousel\">
        <div class=\"container\">
            <div class=\"carousel-inner\" role=\"listbox\">
                <div class=\"item active\">
                    <div class=\"banner-text\">
                        <div class=\"row\">
                            <div class=\"col-sm-6 col-lg-6 col-md-6\">
                                <h1 class=\"iq-font-white iq-tw-8 animated fadeInLeft\">
                                    YOUR ALL PAYMENT !
                                    <small class=\"iq-font-white iq-tw-5 iq-mt-20\">Revolusi teknologi pembayaran dari BNI. </br> Kamu gak perlu lagi takut ketinggalan dompet.</small>
                                </h1>
                                <div class=\"link\">
                                    <h5 class=\"iq-font-white animated fadeInLeft\">Tersedia di</h5>
                                    <ul class=\"list-inline animated fadeInUp\">
                                        <!--li><a href=\"#\"><img src=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/Appstore_Badge.png\" alt=\"\"></a></li>
                                        <li-->
                                            <a href=\"https://play.google.com/store/apps/details?id=id.co.bni.yapcustomer\">
                                                <img src=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/Playstore_Badge.png\" alt=\"\">
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class=\"col-sm-5 col-lg-5 col-md-5 hidden-xs animated fadeInRight\">
                                <div class=\"iq-mobile-app text-right\">
                                    <div class=\"iq-mobile-box\">
                                        <img class=\"iq-mobile-img\" src=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/Hp.png\" alt=\"#\">
                                        <span data-depth=\"0.8\" class=\"layer iq-mobile-icon icon-01\" data-bottom=\"transform:translateX(50px)\" data-top=\"transform:translateX(-100px);\">
                                            <img src=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/1.png\" alt=\"#\" class=\"animated bounceIn\">
                                        </span>
                                        <span data-depth=\"0.8\" class=\"layer iq-mobile-icon icon-04\" data-bottom=\"transform:translateX(-30px)\" data-top=\"transform:translateX(0px);\">
                                            <img src=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/3.png\" alt=\"#\" class=\"animated bounceIn\">
                                        </span>
                                        <span data-depth=\"0.8\" class=\"layer iq-mobile-icon icon-05\" data-bottom=\"transform:translateX(0px)\" data-top=\"transform:translateX(-50px);\">
                                            <img src=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/2.png\" alt=\"#\" class=\"animated bounceIn\">
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<!-- Banner End -->

<div class=\"main-content\">

    <!-- Feature -->

    <section id=\"about-us\" class=\"overview-block-ptb\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">yap! kamu bisa bayar apapun  menggunakan smartphone kamu dengan 3 pilihan sumber dana sesuai keinginan kamu</h2>
                        <div class=\"divider\"></div>
                        <p>Kartu kredit + Debit + UnikQu = yap!</p>
                    </div>
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-12 col-md-4\">
                    <div class=\"iq-fancy-box text-center\">
                        <img src=\"";
        // line 77
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/illustration-2.png\" alt=\"#\">
                        <h4 class=\"iq-tw-6\">Mudah</h4>
                        <p>Kamu bisa akses uang kamu, dari handphone kamu.</p>
                    </div>
                </div>
                <div class=\"col-sm-12 col-md-4 re-mt-30\">
                    <div class=\"iq-fancy-box text-center\">
                        <img src=\"";
        // line 84
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/illustration-3.png\" alt=\"#\">
                        <h4 class=\"iq-tw-6\">Aman</h4>
                        <p>Pembayaran langsung dari akun bank kamu, dan tentunya aman.</p>
                    </div>
                </div>
                <div class=\"col-sm-12 col-md-4 re-mt-30\">
                    <div class=\"iq-fancy-box text-center\">
                        <img src=\"";
        // line 91
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/illustration-4.png\" alt=\"#\">
                        <h4 class=\"iq-tw-6\">Gratis</h4>
                        <p>Tidak ada biaya untuk setiap transaksi kamu.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Feature END -->


    <!-- About Our App -->

    <section class=\"iq-about grey-bg iq-mtb-40\">
        <div class=\"container\">
            <div class=\"row row-eq-height\">
                <div class=\"col-sm-12 col-lg-5 col-md-5 iq-about-bg\">
                    <div class=\"iq-bg about-img popup-gallery play-video\">
                        <img class=\"img-responsive center-block\" src=\"";
        // line 110
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/scr3.png\" alt=\"#\">
                        <a href=\"";
        // line 111
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/video/main2.mp4\" class=\"iq-video popup-youtube\"><i class=\"ion-ios-play-outline\"></i></a>
                        <div class=\"iq-waves\">
                            <div class=\"waves wave-1\"></div>
                            <div class=\"waves wave-2\"></div>
                            <div class=\"waves wave-3\"></div>
                        </div>
                    </div>
                </div>
                <div class=\"col-sm-12 col-lg-7 col-md-7 iq-pall-50\">
                    <h2 class=\"heading-left iq-tw-6 \">Tentang Aplikasi yap!</h2>
                    <p>Aplikasi yap! merupakan solusi pembayaran masa kini yang dilakukan dengan scan QR code melalui smartphone kamu. Sumber dana dari metode pembayaran dapat dilakukan terdiri dari 3 pilihan yaitu kartu kredit, debit dan UnikQu. Aplikasi yap! dapat didownload melalui playstore. yap! <i>easy way to pay.</i></p>
                    <!--a class=\"button iq-mt-15\" href=\"# \">Download Manual Book</a-->
                </div>
            </div>
        </div>
    </section>

    <!-- About Our App END -->


    <!-- Special Features -->

    <section id=\"features\" class=\"overview-block-ptb iq-amazing-tab white-bg\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">Beragam Kelebihan</h2>
                        <div class=\"divider\"></div>
                        <!-- <p>Berkat relasi yang terjalin baik selama bertahun-tahun dengan mitra pembayaran nasional maupun internasional, YAP! dapat menyajikan metode pembayaran terlengkap bahkan menfasilitasi transaksi dengan mata uang asing tertentu yang siap mendukung para merchant memperluas pasar serta meningkatkan pendapatan bisnisnya.</p> -->
                    </div>
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-6 col-md-4 col-lg-4\">
                    <!-- Nav tabs -->
                    <ul class=\"nav nav-tabs\" role=\"tablist\">
                        <li role=\"presentation\" class=\"active wow fadeInLeft\" data-wow-duration=\"1s\">
                            <a class=\"round-right\" href=\"#design\" aria-controls=\"design\" role=\"tab\" data-toggle=\"tab\">
                                <div class=\"iq-fancy-box-01 text-right\">
                                    <i aria-hidden=\"true\" class=\"ion-ios-checkmark-outline\"></i>
                                    <h4 class=\"iq-tw-6\">Widely Acceptance</h4>
                                    <div class=\"fancy-content-01\">
                                        <p>Dapat digunakan oleh seluruh nasabah BNI tanpa terkecuali</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li role=\"presentation\" class=\"wow fadeInLeft\" data-wow-duration=\"1s\" >
                            <a class=\"round-right\" href=\"#resolution\" aria-controls=\"resolution\" role=\"tab\" data-toggle=\"tab\">
                                <div class=\"iq-fancy-box-01 text-right\">
                                    <i aria-hidden=\"true\" class=\"ion-ios-color-wand-outline\"></i>
                                    <h4 class=\"iq-tw-6\">Easy</h4>
                                    <div class=\"fancy-content-01\">
                                        <p>Cara transaksi yang mudah, hanya dengan Log In, Scan, dan Bayar</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li role=\"presentation\" class=\"wow fadeInLeft\" data-wow-duration=\"1s\">
                            <a class=\"round-right\" href=\"#ready\" aria-controls=\"ready\" role=\"tab\" data-toggle=\"tab\">
                                <div class=\"iq-fancy-box-01 text-right\">
                                    <i aria-hidden=\"true\" class=\"ion-ios-copy-outline\"></i>
                                    <h4 class=\"iq-tw-6\">Modern Lifestyle</h4>
                                    <div class=\"fancy-content-01\">
                                        <p>Gaya hidup masa kini yang serba digital</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class=\"col-md-4 text-center hidden-sm hidden-xs\">
                    <!-- Tab panes -->
                    <div class=\"tab-content\">
                        <div role=\"tabpanel\" class=\"tab-pane active\" id=\"design\"><img src=\"";
        // line 186
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/screen/screen-4.png\" class=\"img-responsive center-block\" alt=\"#\"></div>
                        <div role=\"tabpanel\" class=\"tab-pane\" id=\"resolution\"><img src=\"";
        // line 187
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/screen/screen-1.png\" class=\"img-responsive center-block\" alt=\"#\"></div>
                        <div role=\"tabpanel\" class=\"tab-pane\" id=\"ready\"><img src=\"";
        // line 188
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/screen-1.png\" class=\"img-responsive center-block\" alt=\"#\"></div>
                        <div role=\"tabpanel\" class=\"tab-pane\" id=\"fertures\"><img src=\"";
        // line 189
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/screen/screen-2.png\" class=\"img-responsive center-block\" alt=\"#\"></div>
                        <div role=\"tabpanel\" class=\"tab-pane\" id=\"face\"><img src=\"";
        // line 190
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/screen-1.png\" class=\"img-responsive center-block\" alt=\"#\"></div>
                        <div role=\"tabpanel\" class=\"tab-pane\" id=\"codes\"><img src=\"";
        // line 191
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/screen-1.png\" class=\"img-responsive center-block\" alt=\"#\"></div>
                    </div>
                </div>
                <div class=\"col-sm-6 col-md-4 col-lg-4\">
                    <ul class=\"nav nav-tabs\" role=\"tablist\">
                        <li role=\"presentation\" class=\"wow fadeInRight\" data-wow-duration=\"1s\">
                            <a href=\"#fertures\" aria-controls=\"fertures\" role=\"tab\" data-toggle=\"tab\">
                                <div class=\"iq-fancy-box-01\">
                                    <i aria-hidden=\"true\" class=\"ion-ios-locked-outline\"></i>
                                    <h4 class=\"iq-tw-6\">Secure</h4>
                                    <div class=\"fancy-content-01\">
                                        <p>Dua lapis pengamanan : Password login dan pin transaksi</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li role=\"presentation\" class=\"wow fadeInRight\" data-wow-duration=\"1s\">
                            <a href=\"#face\" aria-controls=\"face\" role=\"tab\" data-toggle=\"tab\">
                                <div class=\"iq-fancy-box-01\">
                                    <i aria-hidden=\"true\" class=\"ion-ios-heart-outline\"></i>
                                    <h4 class=\"iq-tw-6\">Convenient</h4>
                                    <div class=\"fancy-content-01\">
                                        <p>Terdapat tiga sumber Dana yaitu dari Kartu Debit, Kartu Kredit dan UniQu</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li role=\"presentation\" class=\"wow fadeInRight\" data-wow-duration=\"1s\">
                            <a href=\"#codes\" aria-controls=\"codes\" role=\"tab\" data-toggle=\"tab\">
                                <div class=\"iq-fancy-box-01\">
                                    <i aria-hidden=\"true\" class=\"ion-arrow-graph-down-right\"></i>
                                    <h4 class=\"iq-tw-6\">Free</h4>
                                    <div class=\"fancy-content-01\">
                                        <p>Bebas biaya operasional</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Special Features END -->

    <section id=\"blog\" class=\"overview-block-ptb white-bg iq-blog\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">Promo</h2>
                        <div class=\"divider\"></div>
                        <p>Jangan sampai terlewat, selalu cek berbagai promo dan informasi terbaru mengenai yap! di sini.</p>
                    </div>
                </div>
            </div>
            <div class=\"row\">
                ";
        // line 249
        if ((twig_length_filter($this->env, (isset($context["data"]) ? $context["data"] : $this->getContext($context, "data"))) > 0)) {
            // line 250
            echo "                    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["data"]) ? $context["data"] : $this->getContext($context, "data")));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 251
                echo "                        <div class=\"col-sm-12 col-md-4\">
                            <div class=\"iq-blog-box\">
                                <div class=\"iq-blog-image clearfix\">
                                    <img class=\"img-responsive center-block\"
                                         src=\"";
                // line 255
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
                echo "/public/photo/promo/";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "image", array()), "html", null, true);
                echo "\" alt=\"#\">
                                </div>
                                <div class=\"iq-blog-detail\">
                                    <div class=\"blog-title\">
                                        <a href=\"";
                // line 259
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("promo_detail", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\">
                                            <h5 class=\"iq-tw-6 text-uppercase\">
                                                ";
                // line 261
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "title", array()), "html", null, true);
                echo "
                                            </h5>
                                        </a>
                                    </div>
                                    <div class=\"iq-blog-meta\">
                                        <ul class=\"list-inline\">
                                            <li>
                                                <a href=\"#\"><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i>
                                                    &nbsp;";
                // line 269
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["item"], "tanggalBerlakuAwal", array()), "d M y"), "html", null, true);
                echo "
                                                </a>
                                            </li>
                                            <li>
                                                Kode Promo : <strong>";
                // line 273
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "kodePromo", array()), "html", null, true);
                echo "</strong>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class=\"blog-content\">
                                        ";
                // line 278
                echo $this->getAttribute($context["item"], "content", array());
                echo "
                                    </div>
                                    <div class=\"blog-button\">
                                        <a href=\"#\" class=\"pull-left iq-tw-6 iq-user\">
                                            <i class=\"fa fa-user-circle\" aria-hidden=\"true\"></i>
                                            <span class=\"text-capitalize\">";
                // line 283
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "author", array()), "firstName", array()), "html", null, true);
                echo "</span>
                                        </a>
                                        <a href=\"";
                // line 285
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("promo_detail", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\" class=\"pull-right iq-tw-6\">Read
                                            More
                                            <i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 294
            echo "
                ";
        } else {
            // line 296
            echo "                    <div class=\"col-sm-12 div-col-md-4\">
                        <div class=\"jumbotron text-center\">
                            <p>Belum ada Promo diterbitkan</p>
                        </div>
                    </div>
                ";
        }
        // line 302
        echo "            </div>

            ";
        // line 307
        echo "        </div>
    </section>

    <!-- <hr> -->

    <!-- <section id=\"blog\" class=\"overview-block-ptb white-bg iq-blog iq-pt-10\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">Informasi</h2>
                        <div class=\"divider\"></div>
                    </div>
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-12 col-md-4\">
                    <div class=\"iq-blog-box\">
                        <div class=\"iq-blog-image clearfix\">
                            <img class=\"img-responsive center-block\" src=\"";
        // line 326
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/images/blog/01.jpg\" alt=\"#\">
                        </div>
                        <div class=\"iq-blog-detail\">
                            <div class=\"blog-title\"> <a href=\"";
        // line 329
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("event_detail", array("id" => 1));
        echo "\"><h5 class=\"iq-tw-6\">Cara Bayar Jaman Now!</h5> </a> </div>
                            <div class=\"iq-blog-meta\">
                                <ul class=\"list-inline\">
                                    <li><a href=\"#\"><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i> 12 Aug 2017</a></li>
                                    <li><a href=\"#\"><i class=\"fa fa-comment-o\" aria-hidden=\"true\"></i> 5</a></li>
                                </ul>
                            </div>
                            <div class=\"blog-content\">
                                <p>Top up (mengisi ulang) YAP!mu bisa memberikan bonus sebesar 100% dari dana yang kamu isi ke YAP!mu. Syaratnya, kamu ...</p>
                            </div>
                            <div class=\"blog-button\">
                                <a href=\"#\" class=\"pull-left iq-tw-6 iq-user\"><i class=\"fa fa-user-circle\" aria-hidden=\"true\"></i> Admin</a>
                                <a href=\"#\" class=\"pull-right iq-tw-6\">Read More <i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i></a> </div>
                        </div>
                    </div>
                </div>
                <div class=\"col-sm-12 col-md-4 re-mt-30\">
                    <div class=\"iq-blog-box\">
                        <div class=\"iq-blog-image clearfix\">
                            <img class=\"img-responsive center-block\" src=\"";
        // line 348
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/images/blog/02.jpg\" alt=\"#\">
                        </div>
                        <div class=\"iq-blog-detail\">
                            <div class=\"blog-title\"> <a href=\"";
        // line 351
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("event_detail", array("id" => 1));
        echo "\"><h5 class=\"iq-tw-6\">Mencairkan Poin</h5> </a> </div>
                            <div class=\"iq-blog-meta\">
                                <ul class=\"list-inline\">
                                    <li><a href=\"#\"><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i> 12 Aug 2017</a></li>
                                    <li><a href=\"#\"><i class=\"fa fa-comment-o\" aria-hidden=\"true\"></i> 5</a></li>
                                </ul>
                            </div>
                            <div class=\"blog-content\">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            </div>
                            <div class=\"blog-button\">
                                <a href=\"#\" class=\"pull-left iq-tw-6 iq-user\"><i class=\"fa fa-user-circle\" aria-hidden=\"true\"></i> Tom Tilak</a>
                                <a href=\"#\" class=\"pull-right iq-tw-6\">Read More <i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i></a> </div>
                        </div>
                    </div>
                </div>
                <div class=\"col-sm-12 col-md-4 re-mt-30\">
                    <div class=\"iq-blog-box\">
                        <div class=\"iq-blog-image clearfix\">
                            <img class=\"img-responsive center-block\" src=\"";
        // line 370
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/images/blog/03.jpg\" alt=\"#\">
                        </div>
                        <div class=\"iq-blog-detail\">
                            <div class=\"blog-title\"> <a href=\"";
        // line 373
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("event_detail", array("id" => 1));
        echo "\"><h5 class=\"iq-tw-6\">Tata cara mengaktifkan akun pada YAP!mu.</h5> </a> </div>
                            <div class=\"iq-blog-meta\">
                                <ul class=\"list-inline\">
                                    <li><a href=\"#\"><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i> 12 Aug 2017</a></li>
                                    <li><a href=\"#\"><i class=\"fa fa-comment-o\" aria-hidden=\"true\"></i> 5</a></li>
                                </ul>
                            </div>
                            <div class=\"blog-content\">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            </div>
                            <div class=\"blog-button\">
                                <a href=\"#\" class=\"pull-left iq-tw-6 iq-user\"><i class=\"fa fa-user-circle\" aria-hidden=\"true\"></i> Admin</a>
                                <a href=\"#\" class=\"pull-right iq-tw-6\">Read More <i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i></a> </div>
                        </div>
                    </div>
                </div>
                <div class=\"col-sm-12 text-center\">
                    <a class=\"button iq-mt-50\" href=\"blog-2-columns.html\">Semua Informasi</a>
                </div>
            </div>
        </div>
    </section> -->

    <!-- App Screenshots -->

    <!-- Frequently Asked Questions -->

    <!--section class=\"overview-block-ptb iq-bg iq-bg-fixed iq-over-black-80\" style=\"background: url(";
        // line 400
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/bg-3.png);\" >
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title iq-mb-40\">
                        <h2 class=\"title iq-tw-6 iq-font-white\">Download Aplikasi yap!</h2>
                        <div class=\"divider white\"></div>
                        <p class=\"iq-font-white\">Aplikasi yap! telah tersedia dalam platform Android.</p>
                    </div>
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-12 text-center\">
                    <a class=\"iq-mr-15\" href=\"https://play.google.com/store/apps/details?id=id.co.bni.yapcustomer\"><img src=\"";
        // line 413
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/Playstore_Badge.png\" alt=\"Playstore\"></a>
                    <!--a class=\"iq-mr-15 re4-mt-20\" href=\"# \"><img src=\"";
        // line 414
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/Appstore_Badge.png\" alt=\"Appstore\"></a>
                </div>
            </div>

        </div>
    </section-->

  <section id=\"blog\" class=\"overview-block-ptb white-bg iq-blog\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">Merchant yap!</h2>
                        <div class=\"divider\"></div>
                        <!--p>Jangan sampai terlewat, selalu cek berbagai promo dan informasi terbaru mengenai yap! di sini.</p-->
                    </div>
                </div>
            </div>
        </div>

        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-lg-12 col-md-12\">
                    <div class=\"owl-carousel\" data-nav-dots=\"false\" data-nav-arrow=\"true\" data-items=\"5\" data-sm-items=\"3\" data-lg-items=\"5\" data-md-items=\"4\" data-autoplay=\"true\">
                        <div class=\"item\"> <img class=\"img-responsive center-block\" <img src=\"";
        // line 438
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/merchant1.png\" alt=\"#\"></div>
                       <div class=\"item\"> <img class=\"img-responsive center-block\" <img src=\"";
        // line 439
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/merchant2.png\" alt=\"#\"></div>
                       <div class=\"item\"> <img class=\"img-responsive center-block\" <img src=\"";
        // line 440
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/merchant3.png\" alt=\"#\"></div>
                       <div class=\"item\"> <img class=\"img-responsive center-block\" <img src=\"";
        // line 441
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/merchant4.png\" alt=\"#\"></div>
                       <div class=\"item\"> <img class=\"img-responsive center-block\" <img src=\"";
        // line 442
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/merchant5.png\" alt=\"#\"></div>
                       <div class=\"item\"> <img class=\"img-responsive center-block\" <img src=\"";
        // line 443
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/merchant6.png\" alt=\"#\"></div>
                       <div class=\"item\"> <img class=\"img-responsive center-block\" <img src=\"";
        // line 444
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/merchant7.png\" alt=\"#\"></div>
                    </div>
                    </br>
                    </br>
                    <center><a class=\"button iq-mt-15\" href=\"#\">Daftar Semua Merchant</a>
                    </center>
                </div>
            </div>


        </div>


    </section>
</div>

";
    }

    public function getTemplateName()
    {
        return "home/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  618 => 444,  614 => 443,  610 => 442,  606 => 441,  602 => 440,  598 => 439,  594 => 438,  567 => 414,  563 => 413,  547 => 400,  517 => 373,  511 => 370,  489 => 351,  483 => 348,  461 => 329,  455 => 326,  434 => 307,  430 => 302,  422 => 296,  418 => 294,  403 => 285,  398 => 283,  390 => 278,  382 => 273,  375 => 269,  364 => 261,  359 => 259,  350 => 255,  344 => 251,  339 => 250,  337 => 249,  276 => 191,  272 => 190,  268 => 189,  264 => 188,  260 => 187,  256 => 186,  178 => 111,  174 => 110,  152 => 91,  142 => 84,  132 => 77,  95 => 43,  89 => 40,  83 => 37,  78 => 35,  66 => 26,  60 => 23,  42 => 8,  38 => 6,  35 => 5,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layouts/layout.html.twig' %}

{% block title %}Beranda{% endblock %}

{% block content %}
<!-- Banner -->

<section id=\"iq-home\" class=\"banner iq-bg iq-bg-fixed iq-box-shadow\" style=\" background: url({{ app.request.basepath }}/public/assets/img/header_blue.png);\">
    <div id=\"carousel-example-generic\" class=\"carousel slide\" data-ride=\"carousel\">
        <div class=\"container\">
            <div class=\"carousel-inner\" role=\"listbox\">
                <div class=\"item active\">
                    <div class=\"banner-text\">
                        <div class=\"row\">
                            <div class=\"col-sm-6 col-lg-6 col-md-6\">
                                <h1 class=\"iq-font-white iq-tw-8 animated fadeInLeft\">
                                    YOUR ALL PAYMENT !
                                    <small class=\"iq-font-white iq-tw-5 iq-mt-20\">Revolusi teknologi pembayaran dari BNI. </br> Kamu gak perlu lagi takut ketinggalan dompet.</small>
                                </h1>
                                <div class=\"link\">
                                    <h5 class=\"iq-font-white animated fadeInLeft\">Tersedia di</h5>
                                    <ul class=\"list-inline animated fadeInUp\">
                                        <!--li><a href=\"#\"><img src=\"{{ app.request.basepath }}/public/assets/img/Appstore_Badge.png\" alt=\"\"></a></li>
                                        <li-->
                                            <a href=\"https://play.google.com/store/apps/details?id=id.co.bni.yapcustomer\">
                                                <img src=\"{{ app.request.basepath }}/public/assets/img/Playstore_Badge.png\" alt=\"\">
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class=\"col-sm-5 col-lg-5 col-md-5 hidden-xs animated fadeInRight\">
                                <div class=\"iq-mobile-app text-right\">
                                    <div class=\"iq-mobile-box\">
                                        <img class=\"iq-mobile-img\" src=\"{{ app.request.basepath}}/public/assets/img/Hp.png\" alt=\"#\">
                                        <span data-depth=\"0.8\" class=\"layer iq-mobile-icon icon-01\" data-bottom=\"transform:translateX(50px)\" data-top=\"transform:translateX(-100px);\">
                                            <img src=\"{{ app.request.basepath}}/public/assets/img/1.png\" alt=\"#\" class=\"animated bounceIn\">
                                        </span>
                                        <span data-depth=\"0.8\" class=\"layer iq-mobile-icon icon-04\" data-bottom=\"transform:translateX(-30px)\" data-top=\"transform:translateX(0px);\">
                                            <img src=\"{{ app.request.basepath}}/public/assets/img/3.png\" alt=\"#\" class=\"animated bounceIn\">
                                        </span>
                                        <span data-depth=\"0.8\" class=\"layer iq-mobile-icon icon-05\" data-bottom=\"transform:translateX(0px)\" data-top=\"transform:translateX(-50px);\">
                                            <img src=\"{{ app.request.basepath}}/public/assets/img/2.png\" alt=\"#\" class=\"animated bounceIn\">
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<!-- Banner End -->

<div class=\"main-content\">

    <!-- Feature -->

    <section id=\"about-us\" class=\"overview-block-ptb\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">yap! kamu bisa bayar apapun  menggunakan smartphone kamu dengan 3 pilihan sumber dana sesuai keinginan kamu</h2>
                        <div class=\"divider\"></div>
                        <p>Kartu kredit + Debit + UnikQu = yap!</p>
                    </div>
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-12 col-md-4\">
                    <div class=\"iq-fancy-box text-center\">
                        <img src=\"{{ app.request.basepath }}/public/assets/img/illustration-2.png\" alt=\"#\">
                        <h4 class=\"iq-tw-6\">Mudah</h4>
                        <p>Kamu bisa akses uang kamu, dari handphone kamu.</p>
                    </div>
                </div>
                <div class=\"col-sm-12 col-md-4 re-mt-30\">
                    <div class=\"iq-fancy-box text-center\">
                        <img src=\"{{ app.request.basepath }}/public/assets/img/illustration-3.png\" alt=\"#\">
                        <h4 class=\"iq-tw-6\">Aman</h4>
                        <p>Pembayaran langsung dari akun bank kamu, dan tentunya aman.</p>
                    </div>
                </div>
                <div class=\"col-sm-12 col-md-4 re-mt-30\">
                    <div class=\"iq-fancy-box text-center\">
                        <img src=\"{{ app.request.basepath }}/public/assets/img/illustration-4.png\" alt=\"#\">
                        <h4 class=\"iq-tw-6\">Gratis</h4>
                        <p>Tidak ada biaya untuk setiap transaksi kamu.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Feature END -->


    <!-- About Our App -->

    <section class=\"iq-about grey-bg iq-mtb-40\">
        <div class=\"container\">
            <div class=\"row row-eq-height\">
                <div class=\"col-sm-12 col-lg-5 col-md-5 iq-about-bg\">
                    <div class=\"iq-bg about-img popup-gallery play-video\">
                        <img class=\"img-responsive center-block\" src=\"{{ app.request.basepath }}/public/assets/img/scr3.png\" alt=\"#\">
                        <a href=\"{{ app.request.basepath }}/public/assets/video/main2.mp4\" class=\"iq-video popup-youtube\"><i class=\"ion-ios-play-outline\"></i></a>
                        <div class=\"iq-waves\">
                            <div class=\"waves wave-1\"></div>
                            <div class=\"waves wave-2\"></div>
                            <div class=\"waves wave-3\"></div>
                        </div>
                    </div>
                </div>
                <div class=\"col-sm-12 col-lg-7 col-md-7 iq-pall-50\">
                    <h2 class=\"heading-left iq-tw-6 \">Tentang Aplikasi yap!</h2>
                    <p>Aplikasi yap! merupakan solusi pembayaran masa kini yang dilakukan dengan scan QR code melalui smartphone kamu. Sumber dana dari metode pembayaran dapat dilakukan terdiri dari 3 pilihan yaitu kartu kredit, debit dan UnikQu. Aplikasi yap! dapat didownload melalui playstore. yap! <i>easy way to pay.</i></p>
                    <!--a class=\"button iq-mt-15\" href=\"# \">Download Manual Book</a-->
                </div>
            </div>
        </div>
    </section>

    <!-- About Our App END -->


    <!-- Special Features -->

    <section id=\"features\" class=\"overview-block-ptb iq-amazing-tab white-bg\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">Beragam Kelebihan</h2>
                        <div class=\"divider\"></div>
                        <!-- <p>Berkat relasi yang terjalin baik selama bertahun-tahun dengan mitra pembayaran nasional maupun internasional, YAP! dapat menyajikan metode pembayaran terlengkap bahkan menfasilitasi transaksi dengan mata uang asing tertentu yang siap mendukung para merchant memperluas pasar serta meningkatkan pendapatan bisnisnya.</p> -->
                    </div>
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-6 col-md-4 col-lg-4\">
                    <!-- Nav tabs -->
                    <ul class=\"nav nav-tabs\" role=\"tablist\">
                        <li role=\"presentation\" class=\"active wow fadeInLeft\" data-wow-duration=\"1s\">
                            <a class=\"round-right\" href=\"#design\" aria-controls=\"design\" role=\"tab\" data-toggle=\"tab\">
                                <div class=\"iq-fancy-box-01 text-right\">
                                    <i aria-hidden=\"true\" class=\"ion-ios-checkmark-outline\"></i>
                                    <h4 class=\"iq-tw-6\">Widely Acceptance</h4>
                                    <div class=\"fancy-content-01\">
                                        <p>Dapat digunakan oleh seluruh nasabah BNI tanpa terkecuali</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li role=\"presentation\" class=\"wow fadeInLeft\" data-wow-duration=\"1s\" >
                            <a class=\"round-right\" href=\"#resolution\" aria-controls=\"resolution\" role=\"tab\" data-toggle=\"tab\">
                                <div class=\"iq-fancy-box-01 text-right\">
                                    <i aria-hidden=\"true\" class=\"ion-ios-color-wand-outline\"></i>
                                    <h4 class=\"iq-tw-6\">Easy</h4>
                                    <div class=\"fancy-content-01\">
                                        <p>Cara transaksi yang mudah, hanya dengan Log In, Scan, dan Bayar</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li role=\"presentation\" class=\"wow fadeInLeft\" data-wow-duration=\"1s\">
                            <a class=\"round-right\" href=\"#ready\" aria-controls=\"ready\" role=\"tab\" data-toggle=\"tab\">
                                <div class=\"iq-fancy-box-01 text-right\">
                                    <i aria-hidden=\"true\" class=\"ion-ios-copy-outline\"></i>
                                    <h4 class=\"iq-tw-6\">Modern Lifestyle</h4>
                                    <div class=\"fancy-content-01\">
                                        <p>Gaya hidup masa kini yang serba digital</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class=\"col-md-4 text-center hidden-sm hidden-xs\">
                    <!-- Tab panes -->
                    <div class=\"tab-content\">
                        <div role=\"tabpanel\" class=\"tab-pane active\" id=\"design\"><img src=\"{{ app.request.basepath }}/public/assets/img/screen/screen-4.png\" class=\"img-responsive center-block\" alt=\"#\"></div>
                        <div role=\"tabpanel\" class=\"tab-pane\" id=\"resolution\"><img src=\"{{ app.request.basepath }}/public/assets/img/screen/screen-1.png\" class=\"img-responsive center-block\" alt=\"#\"></div>
                        <div role=\"tabpanel\" class=\"tab-pane\" id=\"ready\"><img src=\"{{ app.request.basepath }}/public/assets/img/screen-1.png\" class=\"img-responsive center-block\" alt=\"#\"></div>
                        <div role=\"tabpanel\" class=\"tab-pane\" id=\"fertures\"><img src=\"{{ app.request.basepath }}/public/assets/img/screen/screen-2.png\" class=\"img-responsive center-block\" alt=\"#\"></div>
                        <div role=\"tabpanel\" class=\"tab-pane\" id=\"face\"><img src=\"{{ app.request.basepath }}/public/assets/img/screen-1.png\" class=\"img-responsive center-block\" alt=\"#\"></div>
                        <div role=\"tabpanel\" class=\"tab-pane\" id=\"codes\"><img src=\"{{ app.request.basepath }}/public/assets/img/screen-1.png\" class=\"img-responsive center-block\" alt=\"#\"></div>
                    </div>
                </div>
                <div class=\"col-sm-6 col-md-4 col-lg-4\">
                    <ul class=\"nav nav-tabs\" role=\"tablist\">
                        <li role=\"presentation\" class=\"wow fadeInRight\" data-wow-duration=\"1s\">
                            <a href=\"#fertures\" aria-controls=\"fertures\" role=\"tab\" data-toggle=\"tab\">
                                <div class=\"iq-fancy-box-01\">
                                    <i aria-hidden=\"true\" class=\"ion-ios-locked-outline\"></i>
                                    <h4 class=\"iq-tw-6\">Secure</h4>
                                    <div class=\"fancy-content-01\">
                                        <p>Dua lapis pengamanan : Password login dan pin transaksi</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li role=\"presentation\" class=\"wow fadeInRight\" data-wow-duration=\"1s\">
                            <a href=\"#face\" aria-controls=\"face\" role=\"tab\" data-toggle=\"tab\">
                                <div class=\"iq-fancy-box-01\">
                                    <i aria-hidden=\"true\" class=\"ion-ios-heart-outline\"></i>
                                    <h4 class=\"iq-tw-6\">Convenient</h4>
                                    <div class=\"fancy-content-01\">
                                        <p>Terdapat tiga sumber Dana yaitu dari Kartu Debit, Kartu Kredit dan UniQu</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li role=\"presentation\" class=\"wow fadeInRight\" data-wow-duration=\"1s\">
                            <a href=\"#codes\" aria-controls=\"codes\" role=\"tab\" data-toggle=\"tab\">
                                <div class=\"iq-fancy-box-01\">
                                    <i aria-hidden=\"true\" class=\"ion-arrow-graph-down-right\"></i>
                                    <h4 class=\"iq-tw-6\">Free</h4>
                                    <div class=\"fancy-content-01\">
                                        <p>Bebas biaya operasional</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Special Features END -->

    <section id=\"blog\" class=\"overview-block-ptb white-bg iq-blog\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">Promo</h2>
                        <div class=\"divider\"></div>
                        <p>Jangan sampai terlewat, selalu cek berbagai promo dan informasi terbaru mengenai yap! di sini.</p>
                    </div>
                </div>
            </div>
            <div class=\"row\">
                {% if data|length > 0 %}
                    {% for item in data %}
                        <div class=\"col-sm-12 col-md-4\">
                            <div class=\"iq-blog-box\">
                                <div class=\"iq-blog-image clearfix\">
                                    <img class=\"img-responsive center-block\"
                                         src=\"{{ app.request.basepath }}/public/photo/promo/{{ item.image }}\" alt=\"#\">
                                </div>
                                <div class=\"iq-blog-detail\">
                                    <div class=\"blog-title\">
                                        <a href=\"{{ path('promo_detail', {id: item.id}) }}\">
                                            <h5 class=\"iq-tw-6 text-uppercase\">
                                                {{ item.title }}
                                            </h5>
                                        </a>
                                    </div>
                                    <div class=\"iq-blog-meta\">
                                        <ul class=\"list-inline\">
                                            <li>
                                                <a href=\"#\"><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i>
                                                    &nbsp;{{ item.tanggalBerlakuAwal|date('d M y') }}
                                                </a>
                                            </li>
                                            <li>
                                                Kode Promo : <strong>{{ item.kodePromo }}</strong>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class=\"blog-content\">
                                        {{ item.content|raw }}
                                    </div>
                                    <div class=\"blog-button\">
                                        <a href=\"#\" class=\"pull-left iq-tw-6 iq-user\">
                                            <i class=\"fa fa-user-circle\" aria-hidden=\"true\"></i>
                                            <span class=\"text-capitalize\">{{ item.author.firstName }}</span>
                                        </a>
                                        <a href=\"{{ path('promo_detail', {id: item.id}) }}\" class=\"pull-right iq-tw-6\">Read
                                            More
                                            <i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    {% endfor %}

                {% else %}
                    <div class=\"col-sm-12 div-col-md-4\">
                        <div class=\"jumbotron text-center\">
                            <p>Belum ada Promo diterbitkan</p>
                        </div>
                    </div>
                {% endif %}
            </div>

            {# <div class=\"jumbotron\">
                <p class=\"text-center\">Segera Hadir...</p>
            </div> #}
        </div>
    </section>

    <!-- <hr> -->

    <!-- <section id=\"blog\" class=\"overview-block-ptb white-bg iq-blog iq-pt-10\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">Informasi</h2>
                        <div class=\"divider\"></div>
                    </div>
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-12 col-md-4\">
                    <div class=\"iq-blog-box\">
                        <div class=\"iq-blog-image clearfix\">
                            <img class=\"img-responsive center-block\" src=\"{{ app.request.basepath }}/public/assets/images/blog/01.jpg\" alt=\"#\">
                        </div>
                        <div class=\"iq-blog-detail\">
                            <div class=\"blog-title\"> <a href=\"{{ path('event_detail', {id: 1}) }}\"><h5 class=\"iq-tw-6\">Cara Bayar Jaman Now!</h5> </a> </div>
                            <div class=\"iq-blog-meta\">
                                <ul class=\"list-inline\">
                                    <li><a href=\"#\"><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i> 12 Aug 2017</a></li>
                                    <li><a href=\"#\"><i class=\"fa fa-comment-o\" aria-hidden=\"true\"></i> 5</a></li>
                                </ul>
                            </div>
                            <div class=\"blog-content\">
                                <p>Top up (mengisi ulang) YAP!mu bisa memberikan bonus sebesar 100% dari dana yang kamu isi ke YAP!mu. Syaratnya, kamu ...</p>
                            </div>
                            <div class=\"blog-button\">
                                <a href=\"#\" class=\"pull-left iq-tw-6 iq-user\"><i class=\"fa fa-user-circle\" aria-hidden=\"true\"></i> Admin</a>
                                <a href=\"#\" class=\"pull-right iq-tw-6\">Read More <i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i></a> </div>
                        </div>
                    </div>
                </div>
                <div class=\"col-sm-12 col-md-4 re-mt-30\">
                    <div class=\"iq-blog-box\">
                        <div class=\"iq-blog-image clearfix\">
                            <img class=\"img-responsive center-block\" src=\"{{ app.request.basepath }}/public/assets/images/blog/02.jpg\" alt=\"#\">
                        </div>
                        <div class=\"iq-blog-detail\">
                            <div class=\"blog-title\"> <a href=\"{{ path('event_detail', {id: 1}) }}\"><h5 class=\"iq-tw-6\">Mencairkan Poin</h5> </a> </div>
                            <div class=\"iq-blog-meta\">
                                <ul class=\"list-inline\">
                                    <li><a href=\"#\"><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i> 12 Aug 2017</a></li>
                                    <li><a href=\"#\"><i class=\"fa fa-comment-o\" aria-hidden=\"true\"></i> 5</a></li>
                                </ul>
                            </div>
                            <div class=\"blog-content\">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            </div>
                            <div class=\"blog-button\">
                                <a href=\"#\" class=\"pull-left iq-tw-6 iq-user\"><i class=\"fa fa-user-circle\" aria-hidden=\"true\"></i> Tom Tilak</a>
                                <a href=\"#\" class=\"pull-right iq-tw-6\">Read More <i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i></a> </div>
                        </div>
                    </div>
                </div>
                <div class=\"col-sm-12 col-md-4 re-mt-30\">
                    <div class=\"iq-blog-box\">
                        <div class=\"iq-blog-image clearfix\">
                            <img class=\"img-responsive center-block\" src=\"{{ app.request.basepath }}/public/assets/images/blog/03.jpg\" alt=\"#\">
                        </div>
                        <div class=\"iq-blog-detail\">
                            <div class=\"blog-title\"> <a href=\"{{ path('event_detail', {id: 1}) }}\"><h5 class=\"iq-tw-6\">Tata cara mengaktifkan akun pada YAP!mu.</h5> </a> </div>
                            <div class=\"iq-blog-meta\">
                                <ul class=\"list-inline\">
                                    <li><a href=\"#\"><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i> 12 Aug 2017</a></li>
                                    <li><a href=\"#\"><i class=\"fa fa-comment-o\" aria-hidden=\"true\"></i> 5</a></li>
                                </ul>
                            </div>
                            <div class=\"blog-content\">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            </div>
                            <div class=\"blog-button\">
                                <a href=\"#\" class=\"pull-left iq-tw-6 iq-user\"><i class=\"fa fa-user-circle\" aria-hidden=\"true\"></i> Admin</a>
                                <a href=\"#\" class=\"pull-right iq-tw-6\">Read More <i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i></a> </div>
                        </div>
                    </div>
                </div>
                <div class=\"col-sm-12 text-center\">
                    <a class=\"button iq-mt-50\" href=\"blog-2-columns.html\">Semua Informasi</a>
                </div>
            </div>
        </div>
    </section> -->

    <!-- App Screenshots -->

    <!-- Frequently Asked Questions -->

    <!--section class=\"overview-block-ptb iq-bg iq-bg-fixed iq-over-black-80\" style=\"background: url({{ app.request.basepath }}/public/assets/img/bg-3.png);\" >
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title iq-mb-40\">
                        <h2 class=\"title iq-tw-6 iq-font-white\">Download Aplikasi yap!</h2>
                        <div class=\"divider white\"></div>
                        <p class=\"iq-font-white\">Aplikasi yap! telah tersedia dalam platform Android.</p>
                    </div>
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-12 text-center\">
                    <a class=\"iq-mr-15\" href=\"https://play.google.com/store/apps/details?id=id.co.bni.yapcustomer\"><img src=\"{{ app.request.basepath }}/public/assets/img/Playstore_Badge.png\" alt=\"Playstore\"></a>
                    <!--a class=\"iq-mr-15 re4-mt-20\" href=\"# \"><img src=\"{{ app.request.basepath }}/public/assets/img/Appstore_Badge.png\" alt=\"Appstore\"></a>
                </div>
            </div>

        </div>
    </section-->

  <section id=\"blog\" class=\"overview-block-ptb white-bg iq-blog\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">Merchant yap!</h2>
                        <div class=\"divider\"></div>
                        <!--p>Jangan sampai terlewat, selalu cek berbagai promo dan informasi terbaru mengenai yap! di sini.</p-->
                    </div>
                </div>
            </div>
        </div>

        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-lg-12 col-md-12\">
                    <div class=\"owl-carousel\" data-nav-dots=\"false\" data-nav-arrow=\"true\" data-items=\"5\" data-sm-items=\"3\" data-lg-items=\"5\" data-md-items=\"4\" data-autoplay=\"true\">
                        <div class=\"item\"> <img class=\"img-responsive center-block\" <img src=\"{{ app.request.basepath }}/public/assets/img/merchant1.png\" alt=\"#\"></div>
                       <div class=\"item\"> <img class=\"img-responsive center-block\" <img src=\"{{ app.request.basepath }}/public/assets/img/merchant2.png\" alt=\"#\"></div>
                       <div class=\"item\"> <img class=\"img-responsive center-block\" <img src=\"{{ app.request.basepath }}/public/assets/img/merchant3.png\" alt=\"#\"></div>
                       <div class=\"item\"> <img class=\"img-responsive center-block\" <img src=\"{{ app.request.basepath }}/public/assets/img/merchant4.png\" alt=\"#\"></div>
                       <div class=\"item\"> <img class=\"img-responsive center-block\" <img src=\"{{ app.request.basepath }}/public/assets/img/merchant5.png\" alt=\"#\"></div>
                       <div class=\"item\"> <img class=\"img-responsive center-block\" <img src=\"{{ app.request.basepath }}/public/assets/img/merchant6.png\" alt=\"#\"></div>
                       <div class=\"item\"> <img class=\"img-responsive center-block\" <img src=\"{{ app.request.basepath }}/public/assets/img/merchant7.png\" alt=\"#\"></div>
                    </div>
                    </br>
                    </br>
                    <center><a class=\"button iq-mt-15\" href=\"#\">Daftar Semua Merchant</a>
                    </center>
                </div>
            </div>


        </div>


    </section>
</div>

{% endblock %}
", "home/index.html.twig", "/Users/macos/Projects/yap_v3/src/Templates/home/index.html.twig");
    }
}
