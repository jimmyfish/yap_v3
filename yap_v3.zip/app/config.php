<?php
/**
 * Created by PhpStorm.
 * User: dzaki
 * Date: 15/11/17
 * Time: 16:00
 */

return [
    'common' => [
        'debug' => true,
        'asset.path' => __DIR__ . '/../public/assets',
        'dokumen.path' => __DIR__ . '/../public/documents',
        'foto.path' => __DIR__ . '/../public/photo'
    ],
    'db' => [
        'db.options' => [
            'driver' => 'pdo_mysql',
            'host' => '127.0.0.1',
            'username' => 'root',
            'password' => 'faster',
            'dbname' => 'yap'
        ],
    ],
    'twig' => [
        'twig.path' => __DIR__ . '/../src/Templates',
        'twig.options' => [
            'auto_reload' => true
        ]
    ],
    'orm' => [
        'orm.em.options' => [
            'mappings' => [
                [
                    'type' => 'annotation',
                    'namespace' => 'Jimmy\Yap\Domain\Entity',
                    'path' => __DIR__ . '/../src/Domain/Entity',
                ]
            ],
        ],
        'orm.proxies_dir' => __DIR__ . '/proxies',
    ],
];
