#!/usr/bin/env bash

php -S localhost:1234